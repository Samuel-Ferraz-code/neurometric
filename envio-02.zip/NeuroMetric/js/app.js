/* =====================================================================
 * app.js — inicialização de cada tela (landing, preparação, login,
 * cadastro, questões, memorização e resultado) + utilitários de UI.
 * Cada página chama NM.app.init("<id da página>") ao final do <body>.
 * ===================================================================== */
(function (NM) {
  "use strict";

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  /* ---------------- aviso flutuante ---------------- */
  function toast(msg) {
    var el = document.getElementById("nm-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "nm-toast"; el.className = "nm-toast"; el.setAttribute("role", "status"); el.setAttribute("aria-live", "polite");
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add("nm-toast-show");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.classList.remove("nm-toast-show"); }, 4200);
  }

  /* ---------------- envio ao backend (opcional) ---------------- */
  NM.sync = {
    /** Envia a tentativa finalizada ao backend quando NM.CONFIG.api.enabled = true. */
    enviarTentativa: function () {
      if (!NM.CONFIG.api || !NM.CONFIG.api.enabled || !window.fetch) return;
      var t = NM.tentativas.atual(); if (!t) return;
      try {
        fetch(NM.CONFIG.api.baseUrl + "/tentativas", {
          method: "POST", keepalive: true,
          headers: { "Content-Type": "application/json", "Authorization": "Bearer " + (NM.auth.token() || "") },
          body: JSON.stringify(t)
        });
      } catch (e) { console.warn("[NeuroMetric] Falha ao enviar tentativa", e); }
    }
  };

  /* ---------------- elementos comuns ---------------- */
  function ligarComuns() {
    // tempo de referência sempre vindo de NM.CONFIG (landing e preparação)
    var min = NM.CONFIG.tempoReferenciaMinutos;
    $$('[data-nm="ref-min"]').forEach(function (el) { el.textContent = min + " min"; });
    $$('[data-nm="ref-text"]').forEach(function (el) { el.textContent = "Tempo estimado: " + min + " minuto" + (min === 1 ? "" : "s"); });

    $$('[data-nm="not-available"]').forEach(function (a) {
      a.addEventListener("click", function (e) { e.preventDefault(); toast(a.getAttribute("data-msg")); });
    });
    $$('[data-nm="google"]').forEach(function (b) {
      b.addEventListener("click", function () {
        toast("O acesso com Google exige integração OAuth no backend e não está disponível neste protótipo. Use e-mail e senha.");
      });
    });
    $$('[data-nm="auth-link"]').forEach(function (a) {
      if (!NM.auth.autenticado()) return;
      a.textContent = "Sair";
      a.setAttribute("href", "#");
      a.addEventListener("click", function (e) { e.preventDefault(); NM.auth.sair(); window.location.reload(); });
    });
    $$('[data-nm="profile"]').forEach(function (b) {
      var u = NM.auth.usuarioAtual();
      if (u) { b.setAttribute("title", u.nome + " (" + u.email + ")"); b.setAttribute("aria-label", "Perfil: " + u.nome); }
      b.addEventListener("click", function () { u ? NM.nav.ir("preparacao") : NM.nav.ir("login", { next: "preparacao" }); });
    });
    $$('[data-nm="logout"]').forEach(function (a) {
      a.addEventListener("click", function (e) { e.preventDefault(); NM.auth.sair(); NM.nav.ir("landing", null, true); });
    });
  }

  /* ---------------- landing ---------------- */
  function landing() {
    var cta = $('[data-nm="cta-login"]');
    if (cta && NM.auth.autenticado()) cta.setAttribute("href", NM.nav.url("preparacao"));
  }

  /* ---------------- preparação ---------------- */
  function preparacao() {
    var andamento = NM.auth.autenticado() && NM.tentativas.emAndamento();
    var rotulo = $('[data-nm="start-label"]');
    if (andamento && rotulo) {
      var n = NM.numeroQuestao(andamento.etapa);
      rotulo.textContent = "Retomar teste" + (n ? " (Questão " + n + ")" : "");
    }
    $$('[data-nm="start"]').forEach(function (b) {
      b.addEventListener("click", function (e) {
        e.preventDefault();
        if (!NM.auth.autenticado()) return NM.nav.ir("login", { next: "start" });
        NM.nav.iniciarOuRetomar();
      });
    });
  }

  /* ---------------- formulários ---------------- */
  var RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function campoWrapper(input) {
    return input.closest(".relative") || input.parentNode;
  }
  function limparErros(form) {
    $$(".nm-field-error", form).forEach(function (p) { p.parentNode.removeChild(p); });
    $$(".nm-invalid", form).forEach(function (el) { el.classList.remove("nm-invalid"); });
    $$("[aria-invalid]", form).forEach(function (el) { el.removeAttribute("aria-invalid"); });
    var a = $(".nm-form-alert", form.parentNode); if (a) a.parentNode.removeChild(a);
  }
  function erroCampo(input, msg) {
    var w = campoWrapper(input);
    w.classList.add("nm-invalid");
    input.setAttribute("aria-invalid", "true");
    var p = document.createElement("p");
    p.className = "nm-field-error";
    p.id = input.id + "-erro";
    p.textContent = msg;
    input.setAttribute("aria-describedby", p.id);
    w.parentNode.insertBefore(p, w.nextSibling);
  }
  function alerta(form, msg, html) {
    var a = document.createElement("div");
    a.className = "nm-form-alert"; a.setAttribute("role", "alert");
    if (html) a.innerHTML = msg; else a.textContent = msg;
    form.parentNode.insertBefore(a, form);
  }
  function carregando(btn, sim, texto) {
    var span = btn.querySelector("span");
    if (sim) { btn.setAttribute("disabled", ""); btn.classList.add("nm-loading"); if (span) { span.setAttribute("data-orig", span.textContent); span.textContent = texto; } }
    else { btn.removeAttribute("disabled"); btn.classList.remove("nm-loading"); if (span && span.getAttribute("data-orig")) span.textContent = span.getAttribute("data-orig"); }
  }
  function ligarOlhos() {
    $$('[data-nm="toggle-pass"]').forEach(function (b) {
      b.addEventListener("click", function () {
        var input = b.parentNode.querySelector("input");
        var mostrar = input.type === "password";
        input.type = mostrar ? "text" : "password";
        b.setAttribute("aria-pressed", mostrar ? "true" : "false");
      });
    });
  }
  function paramsNext() { var n = NM.nav.param("next"); return n ? { next: n } : null; }

  function cadastro() {
    ligarOlhos();
    $$('[data-nm="go-login"]').forEach(function (el) {
      el.addEventListener("click", function (e) { e.preventDefault(); NM.nav.ir("login", paramsNext()); });
    });
    var form = $('[data-nm="signup-form"]'); if (!form) return;
    var tel = $("#phone", form);
    tel.addEventListener("input", function () {
      var d = tel.value.replace(/\D/g, "").slice(0, 11), s = d;
      if (d.length > 2) s = "(" + d.slice(0, 2) + ") " + d.slice(2);
      if (d.length > 6) s = "(" + d.slice(0, 2) + ") " + d.slice(2, d.length === 11 ? 7 : 6) + "-" + d.slice(d.length === 11 ? 7 : 6);
      tel.value = s;
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      limparErros(form);
      var f = {
        email: $("#email", form), nome: $("#fullname", form), idade: $("#age", form), tel: tel,
        senha: $("#password", form), conf: $("#password_confirm", form), termos: $("#terms", form)
      };
      var v = {
        email: f.email.value.trim().toLowerCase(), nome: f.nome.value.trim().replace(/\s+/g, " "),
        idade: f.idade.value.trim(), tel: f.tel.value.replace(/\D/g, ""), senha: f.senha.value, conf: f.conf.value
      };
      var erros = 0;
      function err(el, m) { erros++; erroCampo(el, m); }
      if (!v.email) err(f.email, "Informe seu e-mail.");
      else if (!RE_EMAIL.test(v.email)) err(f.email, "Informe um e-mail válido (ex.: nome@dominio.com).");
      if (!v.nome) err(f.nome, "Informe seu nome completo.");
      else if (v.nome.length < 3 || !/[A-Za-zÀ-ÿ]/.test(v.nome)) err(f.nome, "O nome deve ter ao menos 3 letras.");
      if (!v.idade) err(f.idade, "Informe sua idade.");
      else if (!/^\d+$/.test(v.idade) || +v.idade < 5 || +v.idade > 120) err(f.idade, "Informe uma idade entre 5 e 120 anos.");
      if (!v.tel) err(f.tel, "Informe seu telefone.");
      else if (v.tel.length < 10 || v.tel.length > 11) err(f.tel, "Telefone com DDD: 10 ou 11 dígitos.");
      if (!v.senha) err(f.senha, "Crie uma senha.");
      else if (v.senha.length < 6) err(f.senha, "A senha deve ter pelo menos 6 caracteres.");
      if (!v.conf) err(f.conf, "Confirme sua senha.");
      else if (v.senha && v.conf !== v.senha) err(f.conf, "As senhas não coincidem.");
      if (!f.termos.checked) err(f.termos, "É preciso aceitar os Termos de Uso e a Política de Privacidade.");
      if (erros) { var primeiro = $("[aria-invalid]", form); if (primeiro) primeiro.focus(); return; }

      if (NM.auth.existeConta(v.email)) {
        alerta(form, 'Já existe uma conta com este e-mail. <a href="#" class="nm-link" data-nm="alert-login">Entrar com esta conta</a>.', true);
        $('[data-nm="alert-login"]').addEventListener("click", function (ev) { ev.preventDefault(); NM.nav.ir("login", paramsNext()); });
        return;
      }
      var btn = $('button[type="submit"]', form);
      carregando(btn, true, "Criando conta…");
      NM.auth.cadastrar({ nome: v.nome, email: v.email, telefone: v.tel, idade: parseInt(v.idade, 10), senha: v.senha })
        .then(function () { NM.nav.aposAutenticar(true); })
        .catch(function (er) { carregando(btn, false); alerta(form, NM.auth.mensagemErro(er)); });
    });
  }

  function login() {
    ligarOlhos();
    $$('[data-nm="go-signup"]').forEach(function (el) {
      el.addEventListener("click", function (e) { e.preventDefault(); NM.nav.ir("cadastro", paramsNext()); });
    });
    var form = $('[data-nm="login-form"]'); if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      limparErros(form);
      var email = $("#email", form), senha = $("#password", form), lembrar = $("#remember", form);
      var v = email.value.trim().toLowerCase(), erros = 0;
      if (!v) { erros++; erroCampo(email, "Informe seu e-mail."); }
      else if (!RE_EMAIL.test(v)) { erros++; erroCampo(email, "Informe um e-mail válido."); }
      if (!senha.value) { erros++; erroCampo(senha, "Informe sua senha."); }
      if (erros) { $("[aria-invalid]", form).focus(); return; }
      var btn = $('button[type="submit"]', form);
      carregando(btn, true, "Entrando…");
      NM.auth.entrar(v, senha.value, lembrar && lembrar.checked)
        .then(function () { NM.nav.aposAutenticar(true); })
        .catch(function (er) {
          carregando(btn, false);
          if (er && er.message === "CREDENCIAIS_INVALIDAS" && !NM.auth.existeConta(v) && !(NM.CONFIG.api && NM.CONFIG.api.enabled)) {
            alerta(form, 'Não encontramos uma conta com este e-mail neste navegador. <a href="#" class="nm-link" data-nm="alert-signup">Criar conta</a>.', true);
            $('[data-nm="alert-signup"]').addEventListener("click", function (ev) { ev.preventDefault(); NM.nav.ir("cadastro", paramsNext()); });
          } else alerta(form, NM.auth.mensagemErro(er));
        });
    });
  }

  /* ---------------- despacho ---------------- */
  NM.app = {
    toast: toast,
    init: function (pagina) {
      ligarComuns();
      var n = NM.numeroQuestao(pagina);
      if (n) return NM.questions.iniciarQuestao(n);
      if (pagina === "memo1") return NM.questions.iniciarMemorizacao(1);
      if (pagina === "memo2") return NM.questions.iniciarMemorizacao(2);
      if (pagina === "resultado") return NM.results.iniciar();
      if (pagina === "landing") return landing();
      if (pagina === "preparacao") return preparacao();
      if (pagina === "login") return login();
      if (pagina === "cadastro") return cadastro();
    }
  };
})(window.NM = window.NM || {});
