/* Gerado a partir das telas originais do Stitch (enunciados, alternativas e imagens sem alteração).
 * Usado pela revisão na tela de resultados. NÃO contém o gabarito (ver js/answer-key.js). */
(function (NM) {
  "use strict";
  NM.QUESTOES = [
  {
    "numero": 1,
    "id": "NM-01",
    "pagina": "pages/questao-01.html",
    "categoria": "Raciocínio Dedutivo",
    "enunciado": "Um fazendeiro tem 50 galinhas. Todas morrem, menos 37. Quantas sobram?",
    "complemento": null,
    "alternativas": {
      "A": "23",
      "B": "20",
      "C": "30",
      "D": "13",
      "E": "37"
    },
    "imagemEnunciado": "assets/images/questoes/q01-enunciado.png",
    "imagensAlternativas": null,
    "estimuloHtml": null
  },
  {
    "numero": 2,
    "id": "NM-02",
    "pagina": "pages/questao-02.html",
    "categoria": "Raciocínio Dedutivo",
    "enunciado": "2 — Joana está em uma competição de natação e ultrapassa a pessoa em 2º lugar. Em que lugar Joana está?",
    "complemento": null,
    "alternativas": {
      "A": "1º lugar",
      "B": "2º lugar",
      "C": "3º lugar",
      "D": "4º lugar",
      "E": "5º lugar"
    },
    "imagemEnunciado": "assets/images/questoes/q02-enunciado.png",
    "imagensAlternativas": null,
    "estimuloHtml": null
  },
  {
    "numero": 3,
    "id": "NM-03",
    "pagina": "pages/questao-03.html",
    "categoria": "Raciocínio Espacial",
    "enunciado": "3 — Quantos vértices tem uma pirâmide quadrangular equilátera?",
    "complemento": null,
    "alternativas": {
      "A": "3",
      "B": "4",
      "C": "5",
      "D": "6",
      "E": "8"
    },
    "imagemEnunciado": "assets/images/questoes/q03-enunciado.png",
    "imagensAlternativas": null,
    "estimuloHtml": null
  },
  {
    "numero": 4,
    "id": "NM-04",
    "pagina": "pages/questao-04.html",
    "categoria": "Sequências Numéricas",
    "enunciado": "4 — Qual é o próximo número desta sequência?",
    "complemento": null,
    "alternativas": {
      "A": "48",
      "B": "36",
      "C": "16",
      "D": "64",
      "E": "92"
    },
    "imagemEnunciado": null,
    "imagensAlternativas": null,
    "estimuloHtml": "<div class=\"my-8 flex justify-center items-center\"><div class=\"bg-white/80 border border-[#CBD5E1]/60 shadow-xs rounded-2xl p-6 sm:px-10 flex flex-wrap items-center justify-center gap-3 sm:gap-4 select-none\"><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#EAF1F5] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">3</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#EAF1F5] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">6</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#EAF1F5] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">12</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#EAF1F5] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">24</div><span class=\"material-symbols-outlined text-[#3B82F6] text-sm font-bold\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl border-2 border-dashed border-[#3B82F6] bg-[#E0EDFF]/50 flex items-center justify-center text-2xl sm:text-3xl font-extrabold text-[#3B82F6] shadow-xs\">?</div></div></div>"
  },
  {
    "numero": 5,
    "id": "NM-05",
    "pagina": "pages/questao-05.html",
    "categoria": "Sequências Numéricas",
    "enunciado": "5 — Qual número está faltando?",
    "complemento": null,
    "alternativas": {
      "A": "28",
      "B": "32",
      "C": "34",
      "D": "30",
      "E": "36"
    },
    "imagemEnunciado": null,
    "imagensAlternativas": null,
    "estimuloHtml": "<div class=\"my-8 flex justify-center items-center\"><div class=\"bg-white/80 border border-[#CBD5E1]/60 shadow-xs rounded-2xl p-6 sm:px-10 flex flex-wrap items-center justify-center gap-3 sm:gap-4 select-none\"><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#E2E8EE] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">6</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#E2E8EE] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">12</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#E2E8EE] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">18</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#E2E8EE] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">24</div><span class=\"material-symbols-outlined text-[#3B82F6] text-sm font-bold\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl border-2 border-dashed border-[#3B82F6] bg-[#E0EDFF]/50 flex items-center justify-center text-2xl sm:text-3xl font-extrabold text-[#3B82F6] shadow-xs\">?</div><span class=\"material-symbols-outlined text-[#64748B] text-sm opacity-60\">arrow_forward</span><div class=\"w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-[#E2E8EE] flex items-center justify-center text-xl sm:text-2xl font-bold text-[#14213D] shadow-xs\">36</div></div></div>"
  },
  {
    "numero": 6,
    "id": "NM-06",
    "pagina": "pages/questao-06.html",
    "categoria": "Memória de Trabalho",
    "enunciado": "6 — Qual era o 4º dígito da sequência mostrada anteriormente?",
    "complemento": null,
    "alternativas": {
      "A": "9",
      "B": "3",
      "C": "7",
      "D": "2",
      "E": "1"
    },
    "imagemEnunciado": null,
    "imagensAlternativas": null,
    "estimuloHtml": null
  },
  {
    "numero": 7,
    "id": "NM-07",
    "pagina": "pages/questao-07.html",
    "categoria": "Raciocínio Visual / Padrões e Matrizes",
    "enunciado": "7 — Qual célula completa a grade?",
    "complemento": null,
    "alternativas": {
      "A": null,
      "B": null,
      "C": null,
      "D": null,
      "E": null
    },
    "imagemEnunciado": "assets/images/questoes/q07-enunciado.png",
    "imagensAlternativas": {
      "A": "assets/images/questoes/q07-alternativa-A.png",
      "B": "assets/images/questoes/q07-alternativa-B.png",
      "C": "assets/images/questoes/q07-alternativa-C.png",
      "D": "assets/images/questoes/q07-alternativa-D.png",
      "E": "assets/images/questoes/q07-alternativa-E.png"
    },
    "estimuloHtml": null
  },
  {
    "numero": 8,
    "id": "NM-08",
    "pagina": "pages/questao-08.html",
    "categoria": "Raciocínio Visual / Padrões e Matrizes",
    "enunciado": "8 — Qual figura completa a imagem?",
    "complemento": null,
    "alternativas": {
      "A": null,
      "B": null,
      "C": null,
      "D": null,
      "E": null
    },
    "imagemEnunciado": "assets/images/questoes/q08-enunciado.png",
    "imagensAlternativas": {
      "A": "assets/images/questoes/q08-alternativa-A.png",
      "B": "assets/images/questoes/q08-alternativa-B.png",
      "C": "assets/images/questoes/q08-alternativa-C.png",
      "D": "assets/images/questoes/q08-alternativa-D.png",
      "E": "assets/images/questoes/q08-alternativa-E.png"
    },
    "estimuloHtml": null
  },
  {
    "numero": 9,
    "id": "NM-09",
    "pagina": "pages/questao-09.html",
    "categoria": "Raciocínio Lógico / Padrões Numéricos",
    "enunciado": "9 — Qual figura continua a rotação?",
    "complemento": null,
    "alternativas": {
      "A": "4",
      "B": "6",
      "C": "8",
      "D": "10",
      "E": "12"
    },
    "imagemEnunciado": null,
    "imagensAlternativas": null,
    "estimuloHtml": "<div class=\"w-full flex flex-col items-center justify-center py-2\"><div class=\"p-4 sm:p-6 rounded-2xl bg-white border border-[#CBD5E1]/60 shadow-sm flex flex-col items-center\">\n<div class=\"grid grid-cols-3 gap-3 sm:gap-4 select-none\">\n<!-- Linha 1 -->\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">2</span>\n</div>\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">4</span>\n</div>\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">6</span>\n</div>\n<!-- Linha 2 -->\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">4</span>\n</div>\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">6</span>\n</div>\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">8</span>\n</div>\n<!-- Linha 3 -->\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">6</span>\n</div>\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-[#EAF1F5] flex items-center justify-center\">\n<span class=\"text-3xl sm:text-4xl font-bold text-[#14213D]\">8</span>\n</div>\n<!-- 9º Quadrado (?) com borda azul tracejada -->\n<div class=\"w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-blue-50 border-2 border-dashed border-[#3B82F6] flex items-center justify-center relative overflow-hidden group shadow-xs\">\n<span class=\"text-3xl sm:text-4xl font-extrabold text-[#3B82F6] relative z-10\">?</span>\n</div>\n</div>\n</div></div>"
  },
  {
    "numero": 10,
    "id": "NM-10",
    "pagina": "pages/questao-10.html",
    "categoria": "Memória de Trabalho",
    "enunciado": "10 — Qual era o 5° dígito?",
    "complemento": null,
    "alternativas": {
      "A": "4",
      "B": "9",
      "C": "3",
      "D": "6",
      "E": "8"
    },
    "imagemEnunciado": null,
    "imagensAlternativas": null,
    "estimuloHtml": null
  },
  {
    "numero": 11,
    "id": "NM-11",
    "pagina": "pages/questao-11.html",
    "categoria": "Raciocínio Visual / Padrões e Matrizes",
    "enunciado": "11 — Qual figura mantém a alternância?",
    "complemento": null,
    "alternativas": {
      "A": null,
      "B": null,
      "C": null,
      "D": null,
      "E": null
    },
    "imagemEnunciado": "assets/images/questoes/q11-enunciado.png",
    "imagensAlternativas": {
      "A": "assets/images/questoes/q11-alternativa-A.png",
      "B": "assets/images/questoes/q11-alternativa-B.png",
      "C": "assets/images/questoes/q11-alternativa-C.png",
      "D": "assets/images/questoes/q11-alternativa-D.png",
      "E": "assets/images/questoes/q11-alternativa-E.png"
    },
    "estimuloHtml": null
  },
  {
    "numero": 12,
    "id": "NM-12",
    "pagina": "pages/questao-12.html",
    "categoria": "Raciocínio Visual / Padrões e Matrizes",
    "enunciado": "12 — Qual célula completa a grade?",
    "complemento": "Analise a progressão lógica das linhas e colunas para identificar o elemento correspondente ao espaço em azul.",
    "alternativas": {
      "A": null,
      "B": null,
      "C": null,
      "D": null,
      "E": null
    },
    "imagemEnunciado": "assets/images/questoes/q12-enunciado.png",
    "imagensAlternativas": {
      "A": "assets/images/questoes/q12-alternativa-A.png",
      "B": "assets/images/questoes/q12-alternativa-B.png",
      "C": "assets/images/questoes/q12-alternativa-C.png",
      "D": "assets/images/questoes/q12-alternativa-D.png",
      "E": "assets/images/questoes/q12-alternativa-E.png"
    },
    "estimuloHtml": null
  }
];
})(window.NM = window.NM || {});
