/* =====================================================================
 * scoring.js — correção automática e cálculo do resumo.
 *
 * Regras:
 *  - aproveitamento        = acertos ÷ 12 × 100
 *  - erros                 = questões corrigidas − acertos
 *                            (com gabarito completo: 12 − acertos)
 *  - tempo médio/questão   = tempo total ÷ 12
 *  - questões sem gabarito configurado ficam "pendentes": não são
 *    classificadas como acerto nem erro, e um percentual separado
 *    considera apenas as questões efetivamente corrigidas.
 * ===================================================================== */
(function (NM) {
  "use strict";

  var LETRAS = /^[A-E]$/;

  function gabaritoDe(n) {
    var g = NM.GABARITO ? NM.GABARITO[n] : null;
    return typeof g === "string" && LETRAS.test(g.toUpperCase()) ? g.toUpperCase() : null;
  }

  /** Retorna cópias das respostas com alternativaCorreta / acertou / status preenchidos. */
  function corrigir(respostas) {
    return (respostas || []).map(function (r) {
      var c = gabaritoDe(r.questao);
      var o = {};
      for (var k in r) if (Object.prototype.hasOwnProperty.call(r, k)) o[k] = r[k];
      o.alternativaCorreta = c;
      o.acertou = c ? r.alternativaSelecionada === c : null;
      o.status = c ? (o.acertou ? "correta" : "incorreta") : "pendente";
      return o;
    }).sort(function (a, b) { return a.questao - b.questao; });
  }

  function resumo(tentativa) {
    var C = NM.CONFIG, total = C.totalQuestoes;
    var respostas = corrigir(tentativa.respostas);
    var corrigidas = respostas.filter(function (r) { return r.status !== "pendente"; });
    var acertos = corrigidas.filter(function (r) { return r.acertou; }).length;
    var pendentes = respostas.filter(function (r) { return r.status === "pendente"; }).map(function (r) { return r.questao; });
    var tempoTotalSeg = NM.timer.totalMs(tentativa) / 1000;

    // por categoria (categorias definidas nas telas originais)
    var mapa = {}, ordem = [];
    respostas.forEach(function (r) {
      var q = (NM.QUESTOES || []).filter(function (x) { return x.numero === r.questao; })[0] || {};
      var cat = q.categoria || "Sem categoria";
      if (!mapa[cat]) { mapa[cat] = { categoria: cat, questoes: [], corrigidas: 0, acertos: 0, erros: 0, pendentes: 0, tempoMs: 0 }; ordem.push(cat); }
      var m = mapa[cat];
      m.questoes.push(r.questao);
      m.tempoMs += r.tempoMs;
      if (r.status === "pendente") m.pendentes++;
      else { m.corrigidas++; if (r.acertou) m.acertos++; else m.erros++; }
    });
    var porCategoria = ordem.map(function (c) {
      var m = mapa[c];
      m.tempoTotalSeg = m.tempoMs / 1000;
      m.tempoMedioSeg = m.questoes.length ? m.tempoTotalSeg / m.questoes.length : 0;
      m.aproveitamento = m.corrigidas ? (m.acertos / m.corrigidas) * 100 : null;
      return m;
    });

    return {
      totalQuestoes: total,
      respondidas: respostas.length,
      corrigidas: corrigidas.length,
      pendentes: pendentes,
      acertos: acertos,
      erros: corrigidas.length - acertos,
      aproveitamento: (acertos / total) * 100,
      aproveitamentoCorrigidas: corrigidas.length ? (acertos / corrigidas.length) * 100 : null,
      tempoTotalSeg: tempoTotalSeg,
      tempoMedioPorQuestao: tempoTotalSeg / total,
      somaTemposQuestoesSeg: respostas.reduce(function (s, r) { return s + r.tempoMs; }, 0) / 1000,
      tempoReferenciaSeg: C.tempoReferenciaSegundos,
      porCategoria: porCategoria,
      respostas: respostas
    };
  }

  /** Verificação de consistência: gabarito das questões de memória x sequências exibidas. */
  function conferirMemoria() {
    var seq = NM.CONFIG.sequenciasMemorizacao, Q = NM.QUESTOES || [];
    function alt(n, L) { var q = Q.filter(function (x) { return x.numero === n; })[0]; return q && q.alternativas[L]; }
    var checks = [[6, seq[1][3]], [10, seq[2][4]]]; // Q6: 4º dígito da 1ª sequência; Q10: 5º dígito da 2ª
    checks.forEach(function (c) {
      var g = gabaritoDe(c[0]);
      if (g && String(alt(c[0], g)) !== String(c[1])) {
        console.warn("[NeuroMetric] Gabarito da Questão " + c[0] + " (" + g + ") não corresponde ao dígito " + c[1] + " da sequência memorizada.");
      }
    });
  }

  NM.scoring = { corrigir: corrigir, resumo: resumo, gabaritoDe: gabaritoDe, conferirMemoria: conferirMemoria };
})(window.NM = window.NM || {});
