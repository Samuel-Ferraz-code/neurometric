/* =====================================================================
 * auth.js — autenticação.
 *
 * ⚠️  AUTENTICAÇÃO DEMONSTRATIVA — NÃO É SEGURA.
 * Sem backend, as contas ficam no localStorage do próprio navegador.
 * A senha NUNCA é gravada em texto puro: guardamos apenas um hash
 * PBKDF2-SHA-256 com sal aleatório (ou SHA-256 iterado, se a Web Crypto
 * API não estiver disponível). Ainda assim, qualquer pessoa com acesso ao
 * navegador pode ler/alterar esses dados. Em produção a autenticação deve
 * ser feita no servidor (ex.: Spring Security + BCrypt + JWT/sessão),
 * ativando NM.CONFIG.api.enabled e o provider "api" abaixo.
 * ===================================================================== */
(function (NM) {
  "use strict";

  var ITERACOES_PBKDF2 = 120000;
  var ITERACOES_FALLBACK = 20000;

  /* ---------------- utilidades ---------------- */
  function hex(buf) {
    var b = new Uint8Array(buf), s = "";
    for (var i = 0; i < b.length; i++) s += (b[i] < 16 ? "0" : "") + b[i].toString(16);
    return s;
  }
  function salAleatorio() {
    var a = new Uint8Array(16);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(a);
    else for (var i = 0; i < a.length; i++) a[i] = Math.floor(Math.random() * 256);
    return hex(a);
  }
  function temSubtle() { return !!(window.crypto && window.crypto.subtle && window.TextEncoder); }

  /* SHA-256 em JavaScript puro (usado só como alternativa quando crypto.subtle não existe). */
  function sha256(ascii) {
    function rr(v, n) { return (v >>> n) | (v << (32 - n)); }
    var mp = Math.pow, max = mp(2, 32), res = "", words = [], i, j;
    var str = unescape(encodeURIComponent(ascii));
    var bitLen = str.length * 8, hash = [], k = [], pc = 0, isC = {};
    for (var c = 2; pc < 64; c++) {
      if (!isC[c]) {
        for (i = 0; i < 313; i += c) isC[i] = c;
        hash[pc] = (mp(c, .5) * max) | 0;
        k[pc++] = (mp(c, 1 / 3) * max) | 0;
      }
    }
    hash = hash.slice(0, 8);
    str += "\x80";
    while (str.length % 64 - 56) str += "\x00";
    for (i = 0; i < str.length; i++) words[i >> 2] |= str.charCodeAt(i) << ((3 - i) % 4) * 8;
    words[words.length] = ((bitLen / max) | 0);
    words[words.length] = bitLen;
    for (j = 0; j < words.length;) {
      var w = words.slice(j, j += 16), old = hash;
      hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = w[i - 15], w2 = w[i - 2], a = hash[0], e = hash[4];
        var t1 = hash[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] +
          (w[i] = (i < 16) ? w[i] : (w[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) | 0);
        var t2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(t1 + t2) | 0].concat(hash);
        hash[4] = (hash[4] + t1) | 0;
      }
      for (i = 0; i < 8; i++) hash[i] = (hash[i] + old[i]) | 0;
    }
    for (i = 0; i < 8; i++) for (j = 3; j + 1; j--) { var b = (hash[i] >> (j * 8)) & 255; res += (b < 16 ? "0" : "") + b.toString(16); }
    return res;
  }

  function derivar(senha, sal, alg) {
    if (alg === "PBKDF2-SHA256") {
      var enc = new TextEncoder();
      return window.crypto.subtle.importKey("raw", enc.encode(senha), "PBKDF2", false, ["deriveBits"])
        .then(function (key) {
          return window.crypto.subtle.deriveBits({ name: "PBKDF2", salt: enc.encode(sal), iterations: ITERACOES_PBKDF2, hash: "SHA-256" }, key, 256);
        }).then(hex);
    }
    return new Promise(function (resolve) {
      var h = sal + ":" + senha;
      for (var i = 0; i < ITERACOES_FALLBACK; i++) h = sha256(h + sal);
      resolve(h);
    });
  }

  /* ---------------- sessão (síncrona: usada pelos guards no <head>) ---------------- */
  function lerSessao() {
    return NM.storage.session.get("sessao", null) || NM.storage.get("sessao", null);
  }
  function gravarSessao(usuario, lembrar, token) {
    var s = { email: usuario.email, nome: usuario.nome, desde: new Date().toISOString(), token: token || null };
    NM.storage.remove("sessao"); NM.storage.session.remove("sessao");
    if (lembrar) NM.storage.set("sessao", s); else NM.storage.session.set("sessao", s);
  }

  /* ---------------- provider local (demonstrativo) ---------------- */
  var local = {
    registrar: function (d) {
      var usuarios = NM.storage.get("usuarios", {});
      if (usuarios[d.email]) return Promise.reject(new Error("CONTA_EXISTENTE"));
      var alg = temSubtle() ? "PBKDF2-SHA256" : "SHA256-ITERADO";
      var sal = salAleatorio();
      return derivar(d.senha, sal, alg).then(function (hash) {
        usuarios[d.email] = {
          nome: d.nome, email: d.email, telefone: d.telefone, idade: d.idade,
          senha: { alg: alg, sal: sal, hash: hash }, // nunca a senha em si
          criadoEm: new Date().toISOString()
        };
        if (!NM.storage.set("usuarios", usuarios)) throw new Error("ARMAZENAMENTO_INDISPONIVEL");
        return { nome: d.nome, email: d.email };
      });
    },
    entrar: function (email, senha) {
      var u = NM.storage.get("usuarios", {})[email];
      if (!u) return Promise.reject(new Error("CREDENCIAIS_INVALIDAS"));
      if (u.senha.alg === "PBKDF2-SHA256" && !temSubtle()) return Promise.reject(new Error("CRIPTO_INDISPONIVEL"));
      return derivar(senha, u.senha.sal, u.senha.alg).then(function (hash) {
        if (hash !== u.senha.hash) throw new Error("CREDENCIAIS_INVALIDAS");
        return { nome: u.nome, email: u.email };
      });
    }
  };

  /* ---------------- provider "api" (Spring Boot) ----------------
   * Contrato sugerido (ver README.md):
   *   POST {baseUrl}/auth/register  { nome, email, telefone, idade, senha } -> { token, usuario: { nome, email } }
   *   POST {baseUrl}/auth/login     { email, senha }                        -> { token, usuario: { nome, email } }
   * Não testado contra um servidor real (nenhum backend foi fornecido).
   */
  function post(caminho, corpo) {
    return fetch(NM.CONFIG.api.baseUrl + caminho, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo)
    }).then(function (r) {
      if (r.status === 409) throw new Error("CONTA_EXISTENTE");
      if (r.status === 401) throw new Error("CREDENCIAIS_INVALIDAS");
      if (!r.ok) throw new Error("FALHA_SERVIDOR");
      return r.json();
    });
  }
  var api = {
    registrar: function (d) { return post("/auth/register", d).then(function (r) { api._token = r.token; return r.usuario; }); },
    entrar: function (email, senha) { return post("/auth/login", { email: email, senha: senha }).then(function (r) { api._token = r.token; return r.usuario; }); }
  };

  function provider() { return NM.CONFIG.api && NM.CONFIG.api.enabled ? api : local; }

  /* ---------------- API pública ---------------- */
  NM.auth = {
    usuarioAtual: function () { return lerSessao(); },
    autenticado: function () { return !!lerSessao(); },
    token: function () { var s = lerSessao(); return s ? s.token : null; },

    /** Cadastra e já inicia a sessão. dados: { nome, email, telefone, idade, senha } */
    cadastrar: function (dados) {
      dados.email = String(dados.email).trim().toLowerCase();
      return provider().registrar(dados).then(function (u) {
        gravarSessao(u, true, api._token);
        return u;
      });
    },

    entrar: function (email, senha, lembrar) {
      email = String(email).trim().toLowerCase();
      return provider().entrar(email, senha).then(function (u) {
        gravarSessao(u, !!lembrar, api._token);
        return u;
      });
    },

    sair: function () { NM.storage.remove("sessao"); NM.storage.session.remove("sessao"); },

    existeConta: function (email) {
      return !!NM.storage.get("usuarios", {})[String(email).trim().toLowerCase()];
    },

    mensagemErro: function (err) {
      var m = {
        CONTA_EXISTENTE: "Já existe uma conta com este e-mail. Use a aba “Entrar” para acessar.",
        CREDENCIAIS_INVALIDAS: "E-mail ou senha incorretos.",
        CRIPTO_INDISPONIVEL: "Este navegador não oferece a Web Crypto API necessária para verificar a senha. Abra o site por um servidor local (veja o README).",
        ARMAZENAMENTO_INDISPONIVEL: "Não foi possível gravar os dados: o armazenamento do navegador está bloqueado.",
        FALHA_SERVIDOR: "O servidor não respondeu corretamente. Tente novamente."
      };
      return m[err && err.message] || "Não foi possível concluir a operação. Tente novamente.";
    }
  };
})(window.NM = window.NM || {});
