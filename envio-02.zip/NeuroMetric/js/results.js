/* =====================================================================
 * results.js — tela de resultados com dados reais da tentativa.
 *
 * Preenche o layout original do Stitch: resumo, cards de métricas,
 * gráfico (Linha / Barras / Pizza em SVG, sem dependências externas),
 * mapa por categoria, tabela detalhada e revisão individual das 12
 * questões. Nenhum valor fictício é usado.
 * ===================================================================== */
(function (NM) {
  "use strict";

  var R; // resumo calculado
  var T; // tentativa

  /* ---------------- formatação ---------------- */
  function num(v, casas) { return Number(v).toFixed(casas === undefined ? 1 : casas).replace(".", ","); }
  function seg(v) { return num(v, 1) + "s"; }
  function mmss(v) { v = Math.round(v); var m = Math.floor(v / 60), s = v % 60; return (m < 10 ? "0" : "") + m + "m " + (s < 10 ? "0" : "") + s + "s"; }
  function esc(s) { return String(s === null || s === undefined ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(k) { return document.querySelector('[data-nm="' + k + '"]'); }
  function set(k, v) { var el = $(k); if (el) el.textContent = v; }
  function listaQ(ns) { return ns.length === 1 ? "a questão " + ns[0] : "as questões " + ns.slice(0, -1).join(", ") + " e " + ns[ns.length - 1]; }

  var COR = { correta: "#2563eb", incorreta: "#dc2626", pendente: "#94a3b8" };

  /* ---------------- resumo e cards ---------------- */
  function preencherResumo() {
    var fim = new Date(T.finalizadaEm);
    set("r-attempt", "TENTATIVA # " + T.numero);
    set("r-date", fim.toLocaleDateString("pt-BR"));
    set("r-time", fim.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }));
    set("r-name", T.usuario && T.usuario.nome ? T.usuario.nome : "—");

    set("r-score", num(R.aproveitamento));
    var bar = $("r-score-bar"); if (bar) bar.style.width = R.aproveitamento.toFixed(2) + "%";
    var desc = "Aproveitamento = acertos ÷ " + R.totalQuestoes + " questões × 100. Você acertou " + R.acertos + " de " + R.totalQuestoes + " questões.";
    if (R.pendentes.length) {
      desc += " " + listaQ(R.pendentes).replace(/^./, function (c) { return c.toUpperCase(); }) +
        (R.pendentes.length > 1 ? " estão" : " está") + " com gabarito pendente e não foram classificadas como acerto ou erro" +
        (R.aproveitamentoCorrigidas !== null ? "; considerando apenas as " + R.corrigidas + " questões corrigidas, o aproveitamento é de " + num(R.aproveitamentoCorrigidas) + "%." : ".");
    }
    desc += " Métrica descritiva de desempenho — não é um QI.";
    set("r-score-desc", desc);

    var ref = R.tempoReferenciaSeg, razao = R.tempoTotalSeg / ref * 100;
    set("r-ref-badge", R.tempoTotalSeg <= ref ? "DENTRO DO TEMPO DE REFERÊNCIA" : "ACIMA DO TEMPO DE REFERÊNCIA");
    set("r-ref-desc", "Você concluiu em " + NM.timer.extenso(R.tempoTotalSeg) + ", o equivalente a " + num(razao, 0) +
      "% do tempo estimado de referência (" + (ref / 60) + " minutos). A referência é apenas uma média esperada: o teste não é encerrado ao atingi-la. Indicador descritivo, sem conversão para escala de QI.");

    set("r-total", String(R.totalQuestoes)); set("r-total-sub", "questões avaliativas");
    set("r-hits", String(R.acertos)); set("r-hits-sub", num(R.aproveitamento) + "% de aproveitamento");
    set("r-errors", String(R.erros)); set("r-errors-sub", "respostas incorretas");
    set("r-pct", num(R.aproveitamento) + "%");
    set("r-pct-sub", R.pendentes.length && R.aproveitamentoCorrigidas !== null ? num(R.aproveitamentoCorrigidas) + "% nas corrigidas" : "acertos ÷ 12");
    set("r-ttotal", NM.timer.extenso(R.tempoTotalSeg)); set("r-ttotal-sub", "referência: " + NM.CONFIG.tempoReferenciaMinutos + " min");
    set("r-tavg", seg(R.tempoMedioPorQuestao)); set("r-tavg-sub", "por questão (total ÷ 12)");
    set("r-graded", String(R.corrigidas)); set("r-graded-sub", "com gabarito configurado");
    set("r-pending", String(R.pendentes.length));
    set("r-pending-sub", R.pendentes.length ? "gabarito pendente: " + R.pendentes.map(function (n) { return "Q" + n; }).join(", ") : "nenhuma pendência");

    var alerta = $("r-pending-alert");
    if (alerta && R.pendentes.length) {
      alerta.className = "bg-white rounded-xl border border-[#fde68a] p-4 flex items-start gap-3 shadow-sm";
      alerta.setAttribute("role", "status");
      alerta.innerHTML =
        '<svg class="w-5 h-5 text-[#d97706] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>' +
        '<div><p class="text-[11px] font-bold uppercase tracking-wider text-[#92400e]">Gabarito pendente de configuração</p>' +
        '<p class="text-[12.5px] text-[#64748b] leading-relaxed mt-0.5">' + listaQ(R.pendentes).replace(/^./, function (c) { return c.toUpperCase(); }) +
        ' ainda não ' + (R.pendentes.length > 1 ? "têm" : "tem") + ' resposta correta definida (arquivo <code>js/answer-key.js</code>). ' +
        'Suas respostas foram registradas, mas não entram na contagem de acertos e erros até que o gabarito seja configurado.</p></div>';
    }
  }

  /* ---------------- gráficos (SVG no estilo do layout original) ---------------- */
  var X0 = 50, X1 = 968, YT = 20, YB = 245;
  function xPos(i, n) { return X0 + (X1 - X0) * (n === 1 ? 0 : i / (n - 1)); }

  function grade(yMax, rotulo) {
    var s = "", passos = 5;
    for (var k = passos; k >= 0; k--) {
      var y = YB - (YB - YT) * k / passos;
      s += '<line stroke="' + (k ? "#e2e8f0" : "#cbd5e1") + '"' + (k ? ' stroke-dasharray="3 3"' : ' stroke-width="1.2"') + ' x1="45" x2="980" y1="' + y + '" y2="' + y + '"></line>';
      s += '<text fill="#94a3b8" font-size="11" text-anchor="end" x="35" y="' + (y + 4) + '">' + rotulo(yMax * k / passos) + '</text>';
    }
    return s;
  }

  function rotulosX(n) {
    var s = "";
    for (var i = 0; i < n; i++) s += '<text fill="#64748b" font-size="11" font-weight="500" text-anchor="middle" x="' + xPos(i, n) + '" y="268">Q' + (i + 1) + '</text>';
    return s;
  }

  function svg(conteudo, rotulo) {
    return '<svg class="w-full h-auto overflow-visible select-none text-xs text-[#94a3b8]" viewBox="0 0 1000 300" role="img" aria-label="' + esc(rotulo) + '" style="font-family: Inter, sans-serif">' + conteudo + '</svg>';
  }

  function graficoLinha() {
    var rs = R.respostas, n = rs.length, pts = [], h = 0, c = 0, ult = null, s = "";
    rs.forEach(function (r, i) {
      if (r.status !== "pendente") { c++; if (r.acertou) h++; ult = h / c * 100; }
      pts.push({ x: xPos(i, n), v: ult, r: r });
    });
    var def = pts.filter(function (p) { return p.v !== null; });
    var y = function (v) { return YB - (YB - YT) * v / 100; };
    s += '<defs><linearGradient id="chartGradient" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#3b82f6" stop-opacity="0.22"></stop><stop offset="100%" stop-color="#3b82f6" stop-opacity="0.02"></stop></linearGradient></defs>';
    s += grade(100, function (v) { return Math.round(v) + "%"; }) + rotulosX(n);
    if (def.length) {
      var linha = def.map(function (p) { return p.x + "," + y(p.v); }).join(" ");
      s += '<polygon fill="url(#chartGradient)" points="' + linha + " " + def[def.length - 1].x + "," + YB + " " + def[0].x + "," + YB + '"></polygon>';
      s += '<polyline fill="none" points="' + linha + '" stroke="#2563eb" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.6"></polyline>';
    }
    pts.forEach(function (p) {
      var yy = p.v === null ? YB : y(p.v), tip = "Q" + p.r.questao + " — " + (p.r.status === "correta" ? "acerto" : p.r.status === "incorreta" ? "erro" : "gabarito pendente") + (p.v !== null ? " • acumulado " + num(p.v) + "%" : "");
      if (p.r.status === "correta") s += '<circle cx="' + p.x + '" cy="' + yy + '" fill="#2563eb" r="3.8"><title>' + tip + '</title></circle>';
      else if (p.r.status === "incorreta") s += '<circle cx="' + p.x + '" cy="' + yy + '" fill="#dc2626" r="4.2" stroke="#ffffff" stroke-width="1.5"><title>' + tip + '</title></circle>';
      else s += '<circle cx="' + p.x + '" cy="' + yy + '" fill="#ffffff" r="4.2" stroke="#94a3b8" stroke-width="2"><title>' + tip + '</title></circle>';
    });
    return svg(s, "Evolução do aproveitamento acumulado por questão");
  }

  function graficoBarras() {
    var rs = R.respostas, n = rs.length, s = "";
    var maxT = Math.max.apply(null, rs.map(function (r) { return r.tempoMs / 1000; }).concat([NM.CONFIG.tempoReferenciaSegundos / NM.CONFIG.totalQuestoes]));
    var passo = maxT <= 30 ? 5 : maxT <= 60 ? 10 : maxT <= 150 ? 30 : 60;
    var yMax = Math.ceil(maxT / passo) * passo || 10;
    s += grade(yMax, function (v) { return Math.round(v) + "s"; }) + rotulosX(n);
    var y = function (v) { return YB - (YB - YT) * v / yMax; }, larg = Math.min(46, (X1 - X0) / n * 0.6);
    rs.forEach(function (r, i) {
      var v = r.tempoMs / 1000, x = xPos(i, n) - larg / 2, yy = y(v);
      s += '<rect x="' + x + '" y="' + yy + '" width="' + larg + '" height="' + Math.max(1, YB - yy) + '" rx="4" fill="' + COR[r.status] + '"><title>Q' + r.questao + ": " + seg(v) + '</title></rect>';
      s += '<text fill="#334155" font-size="11" font-weight="600" text-anchor="middle" x="' + xPos(i, n) + '" y="' + (yy - 6) + '">' + Math.round(v) + 's</text>';
    });
    var ref = NM.CONFIG.tempoReferenciaSegundos / NM.CONFIG.totalQuestoes, yr = y(ref);
    s += '<line stroke="#6366f1" stroke-dasharray="6 4" stroke-width="1.5" x1="45" x2="980" y1="' + yr + '" y2="' + yr + '"></line>';
    s += '<text fill="#6366f1" font-size="11" font-weight="600" text-anchor="end" x="980" y="' + (yr - 6) + '">média de referência: ' + num(ref, 0) + 's/questão</text>';
    return svg(s, "Tempo gasto em cada questão");
  }

  function graficoPizza() {
    var fatias = [
      { rot: "Acertos", v: R.acertos, cor: COR.correta },
      { rot: "Erros", v: R.erros, cor: COR.incorreta },
      { rot: "Gabarito pendente", v: R.pendentes.length, cor: COR.pendente }
    ].filter(function (f) { return f.v > 0; });
    var tot = fatias.reduce(function (a, f) { return a + f.v; }, 0) || 1, cx = 330, cy = 145, r = 118, ang = -Math.PI / 2, s = "";
    fatias.forEach(function (f) {
      var a = f.v / tot * Math.PI * 2;
      if (f.v === tot) s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + f.cor + '"><title>' + f.rot + ": " + f.v + '</title></circle>';
      else {
        var x1 = cx + r * Math.cos(ang), y1 = cy + r * Math.sin(ang), x2 = cx + r * Math.cos(ang + a), y2 = cy + r * Math.sin(ang + a);
        s += '<path d="M' + cx + "," + cy + " L" + x1 + "," + y1 + " A" + r + "," + r + " 0 " + (a > Math.PI ? 1 : 0) + " 1 " + x2 + "," + y2 + ' Z" fill="' + f.cor + '" stroke="#ffffff" stroke-width="2"><title>' + f.rot + ": " + f.v + '</title></path>';
      }
      ang += a;
    });
    var ly = 95;
    fatias.forEach(function (f) {
      s += '<rect x="520" y="' + (ly - 11) + '" width="14" height="14" rx="3" fill="' + f.cor + '"></rect>';
      s += '<text x="544" y="' + ly + '" fill="#0f172a" font-size="15" font-weight="700">' + f.rot + '</text>';
      s += '<text x="544" y="' + (ly + 20) + '" fill="#64748b" font-size="12">' + f.v + " de " + R.totalQuestoes + " questões (" + num(f.v / R.totalQuestoes * 100) + '%)</text>';
      ly += 56;
    });
    return svg(s, "Distribuição de acertos e erros");
  }

  var GRAFICOS = {
    line: { titulo: "Evolução do desempenho acumulado", fn: graficoLinha,
      nota: "Após cada questão: acertos acumulados ÷ questões corrigidas acumuladas × 100. Pontos vermelhos indicam respostas incorretas; pontos vazados, questões com gabarito pendente. Nenhuma curva de QI é exibida, pois não há parâmetros normativos calibrados." },
    bar: { titulo: "Tempo gasto em cada questão", fn: graficoBarras,
      nota: "Tempo individual registrado pelo cronômetro “Esta questão” (pausas descontadas). Azul: acerto • vermelho: erro • cinza: gabarito pendente. A linha tracejada indica a média de referência (5 minutos ÷ 12 questões)." },
    pie: { titulo: "Distribuição de acertos e erros", fn: graficoPizza,
      nota: "Proporção de acertos, erros e questões ainda sem gabarito configurado entre as 12 questões." }
  };

  function mostrarGrafico(tipo) {
    var g = GRAFICOS[tipo]; if (!g) return;
    set("r-chart-title", g.titulo);
    set("r-chart-note", g.nota);
    var box = $("r-chart"); if (box) box.innerHTML = g.fn();
    var btns = document.querySelectorAll('[data-nm="r-chart-btn"]');
    for (var i = 0; i < btns.length; i++) {
      var ativo = btns[i].getAttribute("data-type") === tipo;
      btns[i].className = "px-3.5 py-1 rounded-md " + (ativo ? "bg-[#1658ea] text-white shadow-sm" : "text-[#475569] hover:text-[#0f172a] transition-colors");
      btns[i].setAttribute("aria-pressed", ativo ? "true" : "false");
    }
    try { NM.storage.session.set("grafico", tipo); } catch (e) { /* conveniência apenas */ }
  }

  /* ---------------- categorias e tabela ---------------- */
  function categorias() {
    var box = $("r-cats"); if (!box) return;
    box.innerHTML = R.porCategoria.map(function (c) {
      var ap = c.aproveitamento;
      return '<div class="bg-white rounded-xl border border-[#e2e8f0] p-4 shadow-sm flex flex-col justify-between">' +
        '<div><div class="flex items-center justify-between gap-2">' +
        '<span class="font-bold text-[13px] text-[#0f172a]">' + esc(c.categoria) + '</span>' +
        '<span class="text-[10.5px] font-semibold px-2 py-0.5 rounded bg-[#f1f5f9] text-[#64748b] whitespace-nowrap">' + c.acertos + "/" + c.corrigidas + (c.pendentes ? " +" + c.pendentes + " pend." : "") + '</span></div>' +
        '<div class="mt-2.5"><span class="text-xl font-extrabold text-[#0f172a]">' + (ap === null ? "—" : num(ap)) + '</span>' +
        '<span class="text-xs font-semibold text-[#64748b]">/100</span></div>' +
        '<div class="w-full bg-[#e8eef8] rounded-full h-1.5 mt-2.5 overflow-hidden"><div class="gradient-progress h-1.5 rounded-full" style="width: ' + (ap || 0).toFixed(1) + '%;"></div></div></div>' +
        '<div class="flex items-center justify-between text-[11px] text-[#64748b] mt-3.5 pt-2 border-t border-[#f8fafc]">' +
        '<span>Média: <strong class="text-[#334155] font-semibold">' + seg(c.tempoMedioSeg) + '</strong></span>' +
        '<span>Precisão: <strong class="text-[#1658ea] font-semibold">' + (ap === null ? "pendente" : num(ap, 0) + "%") + '</strong></span></div></div>';
    }).join("");
  }

  function tabela() {
    var tb = $("r-table"); if (!tb) return;
    var linhas = R.porCategoria.map(function (c) {
      var ap = c.aproveitamento;
      return '<tr class="hover:bg-[#f8fafc] transition-colors">' +
        '<td class="py-2.5 px-3 font-semibold text-[#0f172a]">' + esc(c.categoria) + '</td>' +
        '<td class="py-2.5 px-3 text-center">' + c.questoes.length + '</td>' +
        '<td class="py-2.5 px-3 text-center font-bold text-[#1658ea]">' + c.acertos + '</td>' +
        '<td class="py-2.5 px-3 text-center' + (c.erros ? " font-semibold text-[#ea384d]" : "") + '">' + c.erros + '</td>' +
        '<td class="py-2.5 px-3 text-center font-semibold">' + (ap === null ? "—" : num(ap, 0) + "%") + '</td>' +
        '<td class="py-2.5 px-3 text-center">' + mmss(c.tempoTotalSeg) + '</td>' +
        '<td class="py-2.5 px-3 text-center">' + seg(c.tempoMedioSeg) + '</td>' +
        '<td class="py-2.5 px-3 text-right">' + c.corrigidas + '</td>' +
        '<td class="py-2.5 px-3 text-right text-[#64748b]">' + c.pendentes + '</td>' +
        '<td class="py-2.5 px-3 text-right font-bold text-[#1658ea]">' + (ap === null ? "—" : num(ap)) + '</td></tr>';
    }).join("");
    var somaQ = R.somaTemposQuestoesSeg;
    linhas += '<tr class="bg-[#f8fafc] font-bold text-[#0f172a] border-t-2 border-[#e2e8f0]">' +
      '<td class="py-3 px-3 uppercase tracking-wider text-[11px]">TOTAL CONSOLIDADO</td>' +
      '<td class="py-3 px-3 text-center">' + R.totalQuestoes + '</td>' +
      '<td class="py-3 px-3 text-center text-[#1658ea]">' + R.acertos + '</td>' +
      '<td class="py-3 px-3 text-center text-[#ea384d]">' + R.erros + '</td>' +
      '<td class="py-3 px-3 text-center">' + (R.aproveitamentoCorrigidas === null ? "—" : num(R.aproveitamentoCorrigidas) + "%") + '</td>' +
      '<td class="py-3 px-3 text-center" title="Soma dos tempos individuais (sem telas de memorização)">' + mmss(somaQ) + '</td>' +
      '<td class="py-3 px-3 text-center">' + seg(somaQ / R.totalQuestoes) + '</td>' +
      '<td class="py-3 px-3 text-right">' + R.corrigidas + '</td>' +
      '<td class="py-3 px-3 text-right text-[#64748b]">' + R.pendentes.length + '</td>' +
      '<td class="py-3 px-3 text-right text-[#1658ea] text-[13px]">' + num(R.aproveitamento) + '</td></tr>';
    tb.innerHTML = linhas;
    var sec = tb.closest("section");
    if (sec && !sec.querySelector(".nm-table-note")) {
      var p = document.createElement("p");
      p.className = "nm-table-note text-[11.5px] text-[#64748b] leading-relaxed mt-4 pt-3 border-t border-[#f1f5f9]";
      p.textContent = "Tempos por categoria somam apenas o tempo dentro de cada questão (cronômetro “Esta questão”). O tempo total da avaliação (" +
        NM.timer.extenso(R.tempoTotalSeg) + ") também inclui as telas de memorização; por isso o tempo médio do resumo (tempo total ÷ 12 = " +
        seg(R.tempoMedioPorQuestao) + ") pode ser maior que o da tabela. Precisão = acertos ÷ questões corrigidas.";
      sec.appendChild(p);
    }
  }

  /* ---------------- revisão individual ---------------- */
  function chip(status) {
    if (status === "correta") return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#ebf3ff] text-[#1658ea] text-[11.5px] font-bold tracking-wide"><span class="w-2 h-2 rounded-full bg-[#1658ea]"></span>ACERTOU</span>';
    if (status === "incorreta") return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#fef2f2] text-[#dc2626] text-[11.5px] font-bold tracking-wide"><span class="w-2 h-2 rounded-full bg-[#dc2626]"></span>ERROU</span>';
    return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#f1f5f9] text-[#64748b] text-[11.5px] font-bold tracking-wide"><span class="w-2 h-2 rounded-full bg-[#94a3b8]"></span>GABARITO PENDENTE</span>';
  }

  function alternativas(q, r) {
    var raiz = NM.nav.raiz(), letras = ["A", "B", "C", "D", "E"];
    function estilo(L) {
      var esc_ = L === r.alternativaSelecionada, cor = L === r.alternativaCorreta;
      if (esc_ && cor) return { box: "border-[#1658ea] bg-[#ebf3ff]", tag: "Sua resposta • correta", tagc: "text-[#1658ea]" };
      if (esc_ && r.status === "incorreta") return { box: "border-[#dc2626] bg-[#fef2f2]", tag: "Sua resposta", tagc: "text-[#dc2626]" };
      if (esc_) return { box: "border-[#1658ea] bg-white", tag: "Sua resposta", tagc: "text-[#1658ea]" };
      if (cor) return { box: "border-[#1658ea] border-dashed bg-white", tag: "Resposta correta", tagc: "text-[#1658ea]" };
      return { box: "border-[#e2e8f0] bg-white", tag: "", tagc: "" };
    }
    if (q.imagensAlternativas) {
      return '<div class="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5">' + letras.map(function (L) {
        var e = estilo(L);
        return '<div class="rounded-xl border-2 ' + e.box + ' p-3 flex flex-col gap-2">' +
          '<div class="flex items-center justify-between gap-1"><span class="w-6 h-6 rounded-md bg-[#f1f5f9] text-[#0f172a] text-xs font-bold flex items-center justify-center">' + L + '</span>' +
          (e.tag ? '<span class="text-[10px] font-bold uppercase tracking-wide text-right ' + e.tagc + '">' + e.tag + '</span>' : "") + '</div>' +
          '<div class="h-20 flex items-center justify-center"><img alt="Alternativa ' + L + '" class="max-h-full max-w-full object-contain" src="' + raiz + q.imagensAlternativas[L] + '"></div></div>';
      }).join("") + '</div>';
    }
    return '<div class="flex flex-col gap-2 mt-5">' + letras.map(function (L) {
      var e = estilo(L);
      return '<div class="flex items-center justify-between gap-3 px-4 py-2.5 rounded-lg border-2 ' + e.box + '">' +
        '<div class="flex items-center gap-3"><span class="w-7 h-7 rounded-lg bg-[#f1f5f9] text-[#0f172a] text-xs font-bold flex items-center justify-center">' + L + '</span>' +
        '<span class="text-[14px] font-semibold text-[#0f172a]">' + esc(q.alternativas[L]) + '</span></div>' +
        (e.tag ? '<span class="text-[10.5px] font-bold uppercase tracking-wide ' + e.tagc + '">' + e.tag + '</span>' : "") + '</div>';
    }).join("") + '</div>';
  }

  function revisao() {
    var box = $("r-review"); if (!box) return;
    var raiz = NM.nav.raiz();
    box.innerHTML = R.respostas.map(function (r) {
      var q = (NM.QUESTOES || []).filter(function (x) { return x.numero === r.questao; })[0] || { alternativas: {} };
      var expl = NM.EXPLICACOES && NM.EXPLICACOES[r.questao];
      var visual = "";
      if (q.imagemEnunciado) visual = '<div class="flex justify-center mt-5"><img alt="Imagem do enunciado da Questão ' + r.questao + '" class="max-h-[220px] w-auto max-w-full object-contain rounded-lg border border-[#e2e8f0] bg-white p-2" src="' + raiz + q.imagemEnunciado + '"></div>';
      else if (q.estimuloHtml) visual = '<div class="mt-2 nm-review-stimulus">' + q.estimuloHtml + '</div>';
      function caixa(rot, val, cls) {
        return '<div class="rounded-lg bg-[#f8fafc] border border-[#e2e8f0] px-3 py-2"><span class="block text-[10px] font-bold uppercase tracking-wider text-[#64748b]">' + rot + '</span><span class="block text-[15px] font-extrabold ' + (cls || "text-[#0f172a]") + '">' + val + '</span></div>';
      }
      return '<article class="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-sm" id="revisao-q' + r.questao + '">' +
        '<div class="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#f1f5f9]">' +
        '<div class="flex flex-wrap items-center gap-1.5 text-[11px] font-semibold tracking-wider text-[#64748b] uppercase">' +
        '<span class="inline-block w-1.5 h-1.5 rounded-full bg-[#1658ea]"></span><span>Questão ' + (r.questao < 10 ? "0" : "") + r.questao + '</span>' +
        '<span class="text-[#94a3b8]">•</span><span>' + esc(r.idItem) + '</span><span class="text-[#94a3b8]">•</span><span>' + esc(q.categoria) + '</span></div>' + chip(r.status) + '</div>' +
        '<h3 class="text-lg font-bold text-[#0f172a] mt-4 leading-snug">' + esc(q.enunciado) + '</h3>' +
        (q.complemento ? '<p class="text-[13px] text-[#64748b] mt-1">' + esc(q.complemento) + '</p>' : "") +
        visual + alternativas(q, r) +
        '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">' +
        caixa("Sua resposta", esc(r.alternativaSelecionada)) +
        caixa("Resposta correta", r.alternativaCorreta ? esc(r.alternativaCorreta) : "Pendente", r.alternativaCorreta ? "text-[#1658ea]" : "text-[#94a3b8]") +
        caixa("Resultado", r.status === "correta" ? "Acerto" : r.status === "incorreta" ? "Erro" : "Não corrigida", r.status === "correta" ? "text-[#1658ea]" : r.status === "incorreta" ? "text-[#dc2626]" : "text-[#94a3b8]") +
        caixa("Tempo gasto", seg(r.tempoMs / 1000)) + '</div>' +
        '<p class="text-[12px] text-[#64748b] leading-relaxed mt-4"><strong class="text-[#334155] font-semibold">Explicação:</strong> ' +
        (expl ? esc(expl) : "não disponível nos arquivos fornecidos.") + '</p></article>';
    }).join("");
  }

  function ligarRevisao() {
    var btn = $("r-review-toggle"), box = $("r-review");
    if (!btn || !box) return;
    btn.setAttribute("aria-expanded", "false");
    btn.addEventListener("click", function () {
      var abrir = box.classList.contains("hidden");
      box.classList.toggle("hidden", !abrir);
      btn.setAttribute("aria-expanded", abrir ? "true" : "false");
      set("r-review-label", abrir ? "Ocultar revisão" : "Mostrar revisão");
      if (abrir) box.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  /* ---------------- inicialização ---------------- */
  NM.results = {
    iniciar: function () {
      T = NM.tentativas.finalizada(NM.nav.param("tentativa"));
      if (!T) return NM.nav.ir("preparacao", null, true);
      NM.scoring.conferirMemoria();
      R = NM.scoring.resumo(T);

      // grava a correção na própria tentativa (alternativaCorreta / acertou)
      NM.tentativas.atualizar(function (t) {
        if (t.id !== T.id) return false;
        t.respostas = R.respostas.map(function (r) { var o = {}; for (var k in r) if (k !== "status") o[k] = r[k]; return o; });
        t.resumo = { acertos: R.acertos, erros: R.erros, corrigidas: R.corrigidas, pendentes: R.pendentes, aproveitamento: R.aproveitamento, tempoTotalSegundos: Math.round(R.tempoTotalSeg), tempoMedioPorQuestao: R.tempoMedioPorQuestao };
      });

      preencherResumo();
      categorias();
      tabela();
      revisao();
      ligarRevisao();
      var btns = document.querySelectorAll('[data-nm="r-chart-btn"]');
      for (var i = 0; i < btns.length; i++) btns[i].addEventListener("click", function () { mostrarGrafico(this.getAttribute("data-type")); });
      mostrarGrafico(NM.storage.session.get("grafico", "line"));

      var novo = $("r-new");
      if (novo) novo.addEventListener("click", function () { NM.nav.ir("preparacao"); });
      window.NM_RESUMO = R; // facilita inspeção no console
    }
  };
})(window.NM = window.NM || {});
