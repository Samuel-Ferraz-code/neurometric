/* =====================================================================
 * timer.js — cronômetros "ESTA QUESTÃO" e "TEMPO TOTAL" e pausa.
 *
 * Os tempos são calculados por diferença de timestamps reais
 * (Date.now()) gravados na tentativa; o setInterval serve apenas para
 * redesenhar o mostrador. Por isso os valores continuam corretos após
 * atualizar a página, trocar de aba ou o navegador atrasar o intervalo.
 *
 *  - Tempo total: começa ao abrir a Questão 1, segue pelas telas de
 *    memorização e para na confirmação da Questão 12.
 *  - Esta questão: começa em 00:00 ao abrir cada questão e para na
 *    confirmação da resposta.
 *  - Pausa: congela os dois cronômetros; o período pausado é descontado.
 *  - 5 minutos é só referência: nada é encerrado automaticamente.
 * ===================================================================== */
(function (NM) {
  "use strict";

  function agoraRef(t, agora) {
    agora = agora || Date.now();
    return t.pausa && t.pausa.ativa ? t.pausa.desde : agora;
  }

  function dois(n) { return (n < 10 ? "0" : "") + n; }

  var T = NM.timer = {
    /** Tempo total (ms) da tentativa, descontando pausas. */
    totalMs: function (t, agora) {
      if (!t || !t.iniciadaEm) return 0;
      var fim = t.finalizadaEm || agoraRef(t, agora);
      return Math.max(0, fim - t.iniciadaEm - (t.pausa ? t.pausa.totalMs : 0));
    },

    /** Tempo (ms) da questão n em andamento, descontando pausas ocorridas durante ela. */
    questaoMs: function (t, n, agora) {
      var resp = T.resposta(t, n);
      if (resp) return resp.tempoMs;
      var q = t && t.questoesAbertas && t.questoesAbertas[n];
      if (!q) return 0;
      var pausas = (t.pausa ? t.pausa.totalMs : 0) - q.pausaBaseMs;
      return Math.max(0, agoraRef(t, agora) - q.abertaEm - pausas);
    },

    resposta: function (t, n) {
      if (!t || !t.respostas) return null;
      for (var i = 0; i < t.respostas.length; i++) if (t.respostas[i].questao === n) return t.respostas[i];
      return null;
    },

    /** "MM:SS" */
    mmss: function (ms) {
      var s = Math.floor(ms / 1000);
      return dois(Math.floor(s / 60)) + ":" + dois(s % 60);
    },
    /** "HH:MM:SS" */
    hhmmss: function (ms) {
      var s = Math.floor(ms / 1000);
      return dois(Math.floor(s / 3600)) + ":" + dois(Math.floor((s % 3600) / 60)) + ":" + dois(s % 60);
    },
    /** "4min 05s" / "38s" */
    extenso: function (seg) {
      seg = Math.round(seg);
      var m = Math.floor(seg / 60), s = seg % 60;
      return m > 0 ? m + "min " + dois(s) + "s" : s + "s";
    },

    /**
     * Atualiza os mostradores do cabeçalho.
     * questao: número da questão cujo tempo é exibido em "ESTA QUESTÃO".
     */
    iniciarMostradores: function (questao) {
      var elQ = document.getElementById("question-timer");
      var elT = document.getElementById("total-timer");
      function desenhar() {
        var t = NM.tentativas.atual(); if (!t) return;
        if (elQ) elQ.textContent = questao ? T.mmss(T.questaoMs(t, questao)) : "00:00";
        if (elT) elT.textContent = T.hhmmss(T.totalMs(t));
      }
      desenhar();
      T._intervalo = window.setInterval(desenhar, 250);
      T.desenhar = desenhar;
    },

    /* ---------------- pausa ---------------- */
    pausar: function () {
      NM.tentativas.atualizar(function (t) {
        if (t.pausa.ativa || t.finalizadaEm) return false;
        t.pausa.ativa = true; t.pausa.desde = Date.now();
      });
      T.mostrarPausa();
    },

    continuar: function () {
      NM.tentativas.atualizar(function (t) {
        if (!t.pausa.ativa) return false;
        var agora = Date.now();
        t.pausa.totalMs += agora - t.pausa.desde;
        t.pausa.registros.push({ inicio: new Date(t.pausa.desde).toISOString(), fim: new Date(agora).toISOString() });
        t.pausa.ativa = false; t.pausa.desde = null;
      });
      var ov = document.getElementById("nm-pause-overlay");
      if (ov) ov.parentNode.removeChild(ov);
      document.documentElement.classList.remove("nm-paused");
      if (T.desenhar) T.desenhar();
    },

    /** Liga o link "Pausar teste" do rodapé e restaura a pausa após recarregar. */
    ligarPausa: function () {
      var links = document.querySelectorAll('[data-nm="pause"]');
      for (var i = 0; i < links.length; i++) {
        links[i].addEventListener("click", function (e) { e.preventDefault(); T.pausar(); });
      }
      var t = NM.tentativas.atual();
      if (t && t.pausa && t.pausa.ativa) T.mostrarPausa();
    },

    mostrarPausa: function () {
      if (document.getElementById("nm-pause-overlay")) return;
      var t = NM.tentativas.atual();
      var ov = document.createElement("div");
      ov.id = "nm-pause-overlay";
      ov.className = "nm-overlay";
      ov.setAttribute("role", "dialog");
      ov.setAttribute("aria-modal", "true");
      ov.setAttribute("aria-labelledby", "nm-pause-title");
      ov.innerHTML =
        '<div class="nm-overlay-card">' +
        '  <div class="nm-overlay-badge"><span class="nm-dot"></span>TESTE PAUSADO</div>' +
        '  <h2 id="nm-pause-title" class="nm-overlay-title">Avaliação pausada</h2>' +
        '  <p class="nm-overlay-text">Os dois cronômetros estão parados e o tempo em pausa não será contabilizado. ' +
        '  Seu progresso está salvo neste navegador.</p>' +
        '  <div class="nm-overlay-times">' +
        '    <div><span>Tempo total</span><strong>' + T.hhmmss(T.totalMs(t)) + '</strong></div>' +
        '  </div>' +
        '  <button type="button" class="nm-btn-gradient" id="nm-resume">Continuar teste' +
        '    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>' +
        '  </button>' +
        '</div>';
      document.body.appendChild(ov);
      document.documentElement.classList.add("nm-paused");
      document.getElementById("nm-resume").addEventListener("click", T.continuar);
      document.getElementById("nm-resume").focus();
    }
  };
})(window.NM = window.NM || {});
