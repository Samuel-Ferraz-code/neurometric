/* =====================================================================
 * NeuroMetric — Cognitive Lab
 * config.js — configuração central do teste e mapa de navegação.
 *
 * Todos os scripts usam o namespace global `NM` (sem ES modules) para que
 * o site funcione também quando aberto direto pelo arquivo (file://),
 * onde navegadores bloqueiam `<script type="module">`.
 * ===================================================================== */
(function (NM) {
  "use strict";

  /** Configuração do teste. Altere aqui o tempo de referência. */
  NM.CONFIG = {
    totalQuestoes: 12,
    tempoReferenciaSegundos: 300, // 5 minutos — apenas referência (não encerra o teste)
    tempoReferenciaMinutos: 5,
    questaoInicial: 1,
    questaoFinal: 12,

    /** Sequências exibidas nas telas intermediárias de memorização. */
    sequenciasMemorizacao: {
      1: [2, 3, 1, 9, 7],     // exibida após a Questão 3 (usada na Questão 6)
      2: [9, 6, 2, 0, 8, 4]   // exibida após a Questão 6 (usada na Questão 10)
    },

    /** Prefixo das chaves gravadas no localStorage / sessionStorage. */
    storagePrefix: "nm.",

    /**
     * Integração futura com backend Java/Spring Boot.
     * Com `enabled: true`, autenticação e envio da tentativa passam a usar a API
     * (ver js/auth.js -> provider "api" e README.md).
     */
    api: {
      enabled: false,
      baseUrl: "http://localhost:8080/api"
    }
  };

  /** Ordem obrigatória das etapas da avaliação (memorizações não contam como questões). */
  NM.FLUXO = [
    "q1", "q2", "q3", "memo1",
    "q4", "q5", "q6", "memo2",
    "q7", "q8", "q9", "q10", "q11", "q12",
    "resultado"
  ];

  /** Arquivo HTML de cada tela, relativo à raiz do projeto. */
  NM.PAGINAS = {
    landing: "index.html",
    preparacao: "pages/preparacao.html",
    login: "pages/login.html",
    cadastro: "pages/cadastro.html",
    memo1: "pages/memorizacao-1.html",
    memo2: "pages/memorizacao-2.html",
    resultado: "pages/resultado.html"
  };
  for (var i = 1; i <= NM.CONFIG.totalQuestoes; i++) {
    NM.PAGINAS["q" + i] = "pages/questao-" + (i < 10 ? "0" + i : i) + ".html";
  }

  /** Número da questão a partir do id da etapa ("q7" -> 7). */
  NM.numeroQuestao = function (etapa) {
    var m = /^q(\d+)$/.exec(etapa || "");
    return m ? parseInt(m[1], 10) : null;
  };
})(window.NM = window.NM || {});
