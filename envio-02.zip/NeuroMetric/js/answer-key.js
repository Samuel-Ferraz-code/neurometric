/* =====================================================================
 * answer-key.js — GABARITO (separado das respostas do participante).
 *
 * Este arquivo é carregado SOMENTE na tela de resultados; as telas de
 * questão não o incluem, para que as respostas corretas não apareçam
 * durante a avaliação.
 *
 * ⚠️  Em produção a correção deve acontecer no backend: qualquer arquivo
 * JavaScript entregue ao navegador pode ser lido pelo usuário.
 *
 * COMO CONFIGURAR AS QUESTÕES 11 E 12
 *   Substitua `null` pela letra correta ("A" a "E"). Exemplo:  11: "C",
 *   Enquanto o valor for `null`, a questão é exibida como
 *   "gabarito pendente" e não conta como acerto nem como erro.
 *   Os resultados já finalizados são recalculados ao abrir o resultado.
 * ===================================================================== */
(function (NM) {
  "use strict";

  NM.GABARITO = {
    1: "E",
    2: "B",
    3: "C",
    4: "A",
    5: "D",
    6: "A",
    7: "B",
    8: "C",
    9: "D",
    10: "E",
    11: null, // PENDENTE DE CONFIGURAÇÃO — não informado nos arquivos
    12: null  // PENDENTE DE CONFIGURAÇÃO — não informado nos arquivos
  };

  /**
   * Explicações exibidas na revisão. Nenhuma explicação foi fornecida nos
   * arquivos originais; preencha quando houver. Ex.: 1: "Sobram as 37 que não morreram."
   */
  NM.EXPLICACOES = {};
})(window.NM = window.NM || {});
