/* =====================================================================
 * storage.js — persistência local e estado da tentativa.
 *
 * - NM.storage: leitura/gravação JSON em localStorage/sessionStorage,
 *   sempre protegida por try/catch (modo privado, armazenamento bloqueado).
 * - NM.tentativas: estrutura centralizada da tentativa do participante
 *   (etapa atual, cronômetros, rascunho de seleção e respostas confirmadas).
 *
 * Chaves gravadas (prefixo "nm."):
 *   nm.usuarios               -> contas da autenticação demonstrativa (auth.js)
 *   nm.sessao                 -> sessão ativa (localStorage se "Lembrar de mim",
 *                                senão sessionStorage)
 *   nm.tentativas.<e-mail>    -> { atual: Tentativa|null, historico: Tentativa[] }
 * ===================================================================== */
(function (NM) {
  "use strict";

  var P = function () { return (NM.CONFIG && NM.CONFIG.storagePrefix) || "nm."; };

  function area(tipo) {
    try { return tipo === "session" ? window.sessionStorage : window.localStorage; }
    catch (e) { return null; }
  }

  function make(tipo) {
    return {
      get: function (chave, padrao) {
        try {
          var a = area(tipo); if (!a) return padrao;
          var v = a.getItem(P() + chave);
          return v === null ? padrao : JSON.parse(v);
        } catch (e) { return padrao; }
      },
      set: function (chave, valor) {
        try { var a = area(tipo); if (a) { a.setItem(P() + chave, JSON.stringify(valor)); return true; } }
        catch (e) { console.warn("[NeuroMetric] Falha ao gravar", chave, e); }
        return false;
      },
      remove: function (chave) {
        try { var a = area(tipo); if (a) a.removeItem(P() + chave); } catch (e) { /* ignora */ }
      }
    };
  }

  NM.storage = make("local");
  NM.storage.session = make("session");

  /* ------------------------------------------------------------------ */
  /* Tentativas                                                          */
  /* ------------------------------------------------------------------ */
  function chaveUsuario(email) { return "tentativas." + String(email || "").toLowerCase(); }

  function email() {
    var u = NM.auth && NM.auth.usuarioAtual();
    return u ? u.email : null;
  }

  function carregar() {
    var e = email(); if (!e) return null;
    return NM.storage.get(chaveUsuario(e), { atual: null, historico: [] });
  }

  function gravar(dados) {
    var e = email(); if (!e) return false;
    return NM.storage.set(chaveUsuario(e), dados);
  }

  NM.tentativas = {
    /** Tentativa em andamento ou recém-finalizada (null se nenhuma). */
    atual: function () { var d = carregar(); return d ? d.atual : null; },

    /** Última tentativa finalizada (ou a de id informado). */
    finalizada: function (id) {
      var d = carregar(); if (!d) return null;
      var todas = (d.atual ? [d.atual] : []).concat(d.historico || []);
      for (var i = 0; i < todas.length; i++) {
        var t = todas[i];
        if (t.finalizadaEm && (!id || t.id === id)) return t;
      }
      return null;
    },

    emAndamento: function () {
      var t = this.atual();
      return t && !t.finalizadaEm ? t : null;
    },

    /** Cria uma nova tentativa (a anterior, se finalizada, vai para o histórico). */
    criar: function () {
      var d = carregar(); if (!d) return null;
      if (d.atual) d.historico = [d.atual].concat(d.historico || []);
      var u = NM.auth.usuarioAtual();
      var numero = (d.historico || []).length + 1;
      d.atual = {
        id: "T" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
        numero: numero,
        usuario: { email: u.email, nome: u.nome },
        criadaEm: new Date().toISOString(),
        etapa: NM.FLUXO[0],
        iniciadaEm: null,      // timestamp (ms) de abertura da Questão 1
        finalizadaEm: null,    // timestamp (ms) da confirmação da Questão 12
        pausa: { ativa: false, desde: null, totalMs: 0, registros: [] },
        questoesAbertas: {},   // { "n": { abertaEm: ms, pausaBaseMs: ms } }
        rascunho: {},          // seleção ainda não confirmada { "n": "A" }
        respostas: [],         // respostas confirmadas (ver questions.js)
        memorizacao: {},       // { "1": { exibidaEm, confirmadaEm } }
        config: {
          totalQuestoes: NM.CONFIG.totalQuestoes,
          tempoReferenciaSegundos: NM.CONFIG.tempoReferenciaSegundos
        }
      };
      gravar(d);
      return d.atual;
    },

    /**
     * Lê a tentativa atual do armazenamento, aplica `fn` e grava.
     * Sempre relê antes de alterar (evita sobrescrever outra aba).
     */
    atualizar: function (fn) {
      var d = carregar(); if (!d || !d.atual) return null;
      var r = fn(d.atual);
      if (r === false) return d.atual;
      gravar(d);
      return d.atual;
    },

    historico: function () { var d = carregar(); return d ? d.historico || [] : []; }
  };
})(window.NM = window.NM || {});
