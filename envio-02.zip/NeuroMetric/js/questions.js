/* =====================================================================
 * questions.js — comportamento das 12 telas de questão e das 2 telas de
 * memorização, aproveitando o HTML original do Stitch.
 *
 * Cada resposta confirmada é gravada assim (tentativa.respostas[]):
 * {
 *   questao: 1,                      // número da questão
 *   idItem: "NM-01",                 // identificador do enunciado (ver js/questions-data.js)
 *   enunciadoRef: "pages/questao-01.html",
 *   alternativaSelecionada: "E",
 *   alternativaCorreta: null,        // preenchida na correção (scoring.js), nunca durante o teste
 *   acertou: null,                   // true | false | null (gabarito pendente)
 *   tempoSegundos: 18,
 *   tempoMs: 18342,
 *   iniciadaEm: "2026-10-16T14:00:00.000Z",
 *   respondidaEm: "2026-10-16T14:00:18.342Z",
 *   imagens: { enunciado: "...png", alternativas: { A: "...png", ... } } | null
 * }
 * ===================================================================== */
(function (NM) {
  "use strict";

  var C = NM.CONFIG;

  function fmtPct(n) { return (n / C.totalQuestoes * 100).toFixed(2).replace(".", ","); }

  function dadosQuestao(n) {
    var lista = NM.QUESTOES || [];
    for (var i = 0; i < lista.length; i++) if (lista[i].numero === n) return lista[i];
    return null;
  }

  /** Barra de progresso, rótulo, percentual e questões restantes. */
  function progresso(n) {
    var pct = (n / C.totalQuestoes) * 100;
    var q = function (sel) { return document.querySelector('[data-nm="' + sel + '"]'); };
    if (q("q-label")) q("q-label").textContent = "Questão " + n + " de " + C.totalQuestoes;
    if (q("q-pct")) q("q-pct").textContent = fmtPct(n) + "% concluído";
    if (q("q-bar")) q("q-bar").style.width = pct.toFixed(2) + "%";
    if (q("q-remaining")) q("q-remaining").textContent = "Questões restantes: " + (C.totalQuestoes - n);
  }

  /* ---------------- aparência das alternativas ---------------- */
  var SEL_BADGE = ["bg-[#3B82F6]", "text-white", "border-[#3B82F6]"];

  function badgeDe(card) { return card.querySelector("span"); }

  function marcar(cards, letra) {
    cards.forEach(function (card) {
      var badge = badgeDe(card);
      var ativo = card.getAttribute("data-letra") === letra;
      card.classList.toggle("selected", ativo);
      card.setAttribute("aria-checked", ativo ? "true" : "false");
      var radio = card.querySelector('input[type="radio"]');
      if (radio) radio.checked = ativo;
      if (badge) {
        badge.className = badge.getAttribute("data-orig-class");
        if (ativo) {
          // remove cores de fundo/texto originais e aplica o destaque azul
          badge.className = badge.className
            .split(/\s+/)
            .filter(function (c) { return !/^(bg-|text-\[#|text-slate-|text-white$)/.test(c); })
            .concat(SEL_BADGE).join(" ");
        }
      }
      // indicador redondo da Questão 9
      var ind = card.querySelector(".option-indicator");
      if (ind) {
        ind.classList.toggle("bg-blue-500", ativo);
        ind.classList.toggle("bg-[#EAF1F5]", !ativo);
        var dot = ind.querySelector("div");
        if (dot) dot.classList.toggle("opacity-0", !ativo);
      }
    });
  }

  function botaoProxima(btn, habilitar) {
    if (!btn) return;
    var off = ["opacity-50", "cursor-not-allowed", "pointer-events-none"];
    if (habilitar) {
      btn.removeAttribute("disabled");
      off.forEach(function (c) { btn.classList.remove(c); });
      btn.classList.add("cursor-pointer");
      btn.setAttribute("aria-disabled", "false");
    } else {
      btn.setAttribute("disabled", "");
      off.forEach(function (c) { btn.classList.add(c); });
      btn.classList.remove("cursor-pointer");
      btn.setAttribute("aria-disabled", "true");
    }
  }

  function prepararCards() {
    var cards = Array.prototype.slice.call(document.querySelectorAll(".option-card"));
    cards.forEach(function (card) {
      var radio = card.querySelector('input[type="radio"]');
      var letra = radio ? radio.value : card.getAttribute("data-value");
      if (!letra) { var b = badgeDe(card); letra = b ? b.textContent.trim() : null; }
      card.setAttribute("data-letra", letra);
      card.setAttribute("role", "radio");
      card.setAttribute("aria-checked", "false");
      var badge = badgeDe(card);
      if (badge && !badge.hasAttribute("data-orig-class")) badge.setAttribute("data-orig-class", badge.className);
    });
    return cards;
  }

  /* ---------------- ampliação de imagem (zoom) ---------------- */
  function ligarZoom(n) {
    var modal = document.getElementById("zoom-modal");
    var abrirEls = [document.getElementById("btn-zoom-stimulus"), document.getElementById("stimulus-img"),
      document.querySelector('[data-nm="zoom"]')].filter(Boolean);
    if (!abrirEls.length) return;
    if (!modal) {
      // Questão 11: o botão de zoom existia sem janela; usa o mesmo modelo da Questão 7
      var img = document.querySelector('[data-nm="stimulus"]');
      if (!img) return;
      modal = document.createElement("div");
      modal.id = "zoom-modal";
      modal.className = "fixed inset-0 bg-[#14213D]/70 backdrop-blur-sm z-50 hidden flex-col items-center justify-center p-4 nm-zoom-modal";
      modal.innerHTML =
        '<div class="relative bg-white p-4 rounded-2xl max-w-2xl w-full flex flex-col items-center shadow-2xl">' +
        '<button aria-label="Fechar zoom" class="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-[#14213D] text-white flex items-center justify-center shadow-lg hover:bg-black transition-colors" id="btn-close-zoom" type="button">' +
        '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" d="M6 6l12 12M18 6L6 18"/></svg></button>' +
        '<div class="w-full flex items-center justify-between pb-2 mb-2 text-xs font-semibold text-[#64748B] uppercase tracking-wider">' +
        '<span>Visualização Ampliada • Questão ' + n + '</span><span class="text-[#3B82F6]">Padrões e Matrizes</span></div>' +
        '<img alt="Estímulo ampliado" class="w-full max-h-[75vh] object-contain rounded-lg" src="' + img.getAttribute("src") + '"></div>';
      document.body.appendChild(modal);
    }
    var fechar = document.getElementById("btn-close-zoom");
    function abrir() { modal.classList.remove("hidden"); modal.classList.add("flex"); }
    function sair() { modal.classList.add("hidden"); modal.classList.remove("flex"); }
    abrirEls.forEach(function (el) { el.addEventListener("click", abrir); });
    if (fechar) fechar.addEventListener("click", sair);
    modal.addEventListener("click", function (e) { if (e.target === modal) sair(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") sair(); });
  }

  /* ---------------- tela de questão ---------------- */
  function iniciarQuestao(n) {
    var etapa = "q" + n;

    // registra a abertura (uma única vez) — inicia "Esta questão" e, na Q1, o tempo total
    NM.tentativas.atualizar(function (t) {
      if (t.questoesAbertas[n]) return false;
      var agora = Date.now();
      t.questoesAbertas[n] = { abertaEm: agora, pausaBaseMs: t.pausa.totalMs };
      if (n === C.questaoInicial && !t.iniciadaEm) t.iniciadaEm = agora;
    });

    progresso(n);
    var cards = prepararCards();
    var btn = document.getElementById("btn-next");
    var t0 = NM.tentativas.atual();
    var selecionada = (t0.rascunho && t0.rascunho[n]) || null;

    marcar(cards, selecionada);
    botaoProxima(btn, !!selecionada);

    cards.forEach(function (card) {
      card.addEventListener("click", function (e) {
        e.preventDefault(); // evita o clique duplicado label -> input
        var letra = card.getAttribute("data-letra");
        selecionada = letra;
        marcar(cards, letra);
        botaoProxima(btn, true);
        NM.tentativas.atualizar(function (t) { t.rascunho[n] = letra; });
      });
      card.setAttribute("tabindex", "0");
      card.addEventListener("keydown", function (e) {
        if (e.key === " " || e.key === "Enter") { e.preventDefault(); card.click(); }
      });
    });

    var enviando = false;
    if (btn) btn.addEventListener("click", function (e) {
      e.preventDefault();
      if (enviando || !selecionada) return;
      enviando = true;
      botaoProxima(btn, false);
      var proxima = null;
      NM.tentativas.atualizar(function (t) {
        // impede respostas duplicadas e confirmação fora da etapa atual (ex.: outra aba)
        if (t.etapa !== etapa || NM.timer.resposta(t, n)) { proxima = t.finalizadaEm ? "resultado" : t.etapa; return false; }
        var agora = Date.now();
        if (t.pausa.ativa) { // não deveria ocorrer (overlay bloqueia), mas mantém consistência
          t.pausa.totalMs += agora - t.pausa.desde; t.pausa.ativa = false; t.pausa.desde = null;
        }
        var aberta = t.questoesAbertas[n];
        var tempoMs = Math.max(0, agora - aberta.abertaEm - (t.pausa.totalMs - aberta.pausaBaseMs));
        var d = dadosQuestao(n) || {};
        t.respostas.push({
          questao: n,
          idItem: d.id || ("NM-" + (n < 10 ? "0" : "") + n),
          enunciadoRef: d.pagina || NM.PAGINAS[etapa],
          alternativaSelecionada: selecionada,
          alternativaCorreta: null,
          acertou: null,
          tempoSegundos: Math.round(tempoMs / 1000),
          tempoMs: tempoMs,
          iniciadaEm: new Date(aberta.abertaEm).toISOString(),
          respondidaEm: new Date(agora).toISOString(),
          imagens: d.imagemEnunciado || d.imagensAlternativas ? { enunciado: d.imagemEnunciado || null, alternativas: d.imagensAlternativas || null } : null
        });
        delete t.rascunho[n];
        t.etapa = NM.nav.proxima(etapa);
        if (n === C.questaoFinal) t.finalizadaEm = agora; // para o tempo total
        proxima = t.etapa;
      });
      if (proxima === "resultado" && NM.sync) NM.sync.enviarTentativa();
      NM.nav.ir(proxima, null, true);
    });

    NM.timer.iniciarMostradores(n);
    NM.timer.ligarPausa();
    ligarZoom(n);
  }

  /* ---------------- tela de memorização ---------------- */
  function iniciarMemorizacao(k) {
    var etapa = "memo" + k;
    var questaoFundo = k === 1 ? 3 : 6; // questão exibida desfocada ao fundo

    NM.tentativas.atualizar(function (t) {
      if (t.memorizacao[k]) return false;
      t.memorizacao[k] = { sequencia: C.sequenciasMemorizacao[k], exibidaEm: new Date().toISOString(), confirmadaEm: null };
    });

    progresso(questaoFundo);
    // ao fundo, mostra a alternativa que o participante realmente escolheu
    var t = NM.tentativas.atual();
    var r = NM.timer.resposta(t, questaoFundo);
    var cards = prepararCards();
    marcar(cards, r ? r.alternativaSelecionada : null);
    cards.forEach(function (c) { c.setAttribute("tabindex", "-1"); c.setAttribute("aria-hidden", "true"); });

    var btn = document.getElementById("btn-confirm-memorize");
    if (btn) {
      btn.addEventListener("click", function () {
        btn.setAttribute("disabled", "");
        var proxima = null;
        NM.tentativas.atualizar(function (tt) {
          if (tt.etapa !== etapa) { proxima = tt.etapa; return false; }
          tt.memorizacao[k].confirmadaEm = new Date().toISOString();
          tt.etapa = NM.nav.proxima(etapa); // a sequência não pode mais ser reaberta
          proxima = tt.etapa;
        });
        NM.nav.ir(proxima, null, true);
      });
    }

    NM.timer.iniciarMostradores(questaoFundo); // tempo final da questão anterior (já parado)
    NM.timer.ligarPausa();
  }

  NM.questions = {
    iniciarQuestao: iniciarQuestao,
    iniciarMemorizacao: iniciarMemorizacao,
    dados: dadosQuestao
  };
})(window.NM = window.NM || {});
