/* =====================================================================
 * navigation.js — rotas entre as telas e proteção do fluxo.
 *
 * Regras garantidas pelo guard (executado no <head> de cada página,
 * antes de a tela ser exibida):
 *  - questões, memorizações e resultado exigem usuário autenticado;
 *  - só a etapa atual da tentativa pode ser aberta: tentar abrir uma
 *    questão futura, uma questão já respondida ou uma memorização já
 *    confirmada redireciona para a etapa correta;
 *  - o resultado só abre depois da confirmação da Questão 12.
 * A navegação usa location.replace() durante o teste para não empilhar
 * telas já concluídas no histórico do navegador.
 * ===================================================================== */
(function (NM) {
  "use strict";

  /** Caminho até a raiz do projeto a partir da página atual. */
  function raiz() {
    var p = window.location.pathname.replace(/\\/g, "/");
    return /\/pages\/[^\/]*$/.test(p) ? "../" : "";
  }

  function url(chave, params) {
    var u = raiz() + NM.PAGINAS[chave];
    if (params) {
      var q = Object.keys(params).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]); }).join("&");
      if (q) u += "?" + q;
    }
    return u;
  }

  function ir(chave, params, substituir) {
    var destino = url(chave, params);
    if (substituir) window.location.replace(destino); else window.location.href = destino;
  }

  function param(nome) {
    var m = new RegExp("[?&]" + nome + "=([^&#]*)").exec(window.location.search);
    return m ? decodeURIComponent(m[1]) : null;
  }

  var ETAPAS_TESTE = NM.FLUXO.filter(function (e) { return e !== "resultado"; });

  NM.nav = {
    raiz: raiz,
    url: url,
    ir: ir,
    param: param,

    /** Guard executado no <head>. Retorna false quando redireciona. */
    guard: function (pagina) {
      document.documentElement.setAttribute("data-nm-page", pagina);
      var autenticado = NM.auth.autenticado();

      if (pagina === "login" || pagina === "cadastro") {
        if (autenticado) { NM.nav.aposAutenticar(true); return false; }
        return true;
      }
      if (pagina === "landing" || pagina === "preparacao") return true;

      if (!autenticado) { ir("login", { next: "start" }, true); return false; }

      var t = NM.tentativas.atual();
      if (pagina === "resultado") {
        if (t && !t.finalizadaEm) { ir(t.etapa, null, true); return false; }
        if (!NM.tentativas.finalizada(param("tentativa"))) { ir("preparacao", null, true); return false; }
        return true;
      }

      // etapas da avaliação
      if (ETAPAS_TESTE.indexOf(pagina) >= 0) {
        if (!t) { ir("preparacao", null, true); return false; }
        if (t.finalizadaEm) { ir("resultado", null, true); return false; }
        if (t.etapa !== pagina) { ir(t.etapa, null, true); return false; }
      }
      return true;
    },

    /** Para onde ir depois de entrar/cadastrar (parâmetro ?next=). */
    aposAutenticar: function (substituir) {
      var next = param("next");
      if (next === "start") return NM.nav.iniciarOuRetomar();
      ir("preparacao", null, substituir);
    },

    /** Inicia uma nova tentativa ou retoma a que estiver em andamento. */
    iniciarOuRetomar: function () {
      if (!NM.auth.autenticado()) return ir("login", { next: "start" });
      var t = NM.tentativas.emAndamento() || NM.tentativas.criar();
      ir(t.etapa, null, true);
    },

    /** Próxima etapa do fluxo. */
    proxima: function (etapa) {
      var i = NM.FLUXO.indexOf(etapa);
      return i >= 0 && i < NM.FLUXO.length - 1 ? NM.FLUXO[i + 1] : null;
    }
  };
})(window.NM = window.NM || {});
