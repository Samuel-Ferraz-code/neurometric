# NeuroMetric — Cognitive Lab

Site da avaliação cognitiva NeuroMetric construído a partir das telas exportadas do Google Stitch.
O visual de cada tela é o HTML original do Stitch; a integração adicionou navegação, autenticação
demonstrativa, 12 questões interativas, dois cronômetros, armazenamento das respostas, correção
automática e a tela de resultados com dados reais.

> **Importante:** este é um protótipo sem backend. A autenticação e a correção rodam no navegador
> e **não são seguras** para produção (veja [Integração com Java/Spring Boot](#integração-com-javaspring-boot)).

---

## Fluxo

```
Página inicial → Preparação → Login ou Cadastro
  → Q1 → Q2 → Q3 → Memorização (2 3 1 9 7)
  → Q4 → Q5 → Q6 → Memorização (9 6 2 0 8 4)
  → Q7 → Q8 → Q9 → Q10 → Q11 → Q12 → Resultado
```

- 12 questões avaliativas + 2 telas de memorização (que não contam como questão).
- Tempo estimado de referência: **5 minutos** (não encerra o teste).

## Estrutura

```
neurometric/
├── index.html                  Página inicial (landing)
├── pages/
│   ├── preparacao.html         Informações do teste e botão de início
│   ├── login.html              Entrar
│   ├── cadastro.html           Criar conta
│   ├── questao-01.html … questao-12.html
│   ├── memorizacao-1.html      Após a Questão 3
│   ├── memorizacao-2.html      Após a Questão 6
│   └── resultado.html          Relatório de resultados + revisão
├── css/
│   ├── style.css               Estilos da integração (validação, pausa, avisos)
│   └── responsive.css          Ajustes para celulares de 320–420 px
├── js/
│   ├── config.js               CONFIG, ordem do fluxo e mapa de páginas
│   ├── storage.js              localStorage/sessionStorage + estado da tentativa
│   ├── auth.js                 Autenticação demonstrativa (hash PBKDF2) + provider de API
│   ├── navigation.js           Rotas e proteção do fluxo (guards)
│   ├── timer.js                Cronômetros "Esta questão" / "Tempo total" e pausa
│   ├── questions.js            Comportamento das telas de questão e memorização
│   ├── questions-data.js       Enunciados, alternativas, categorias e imagens (para a revisão)
│   ├── answer-key.js           GABARITO (carregado só na tela de resultados)
│   ├── scoring.js              Correção automática e resumo
│   ├── results.js              Tela de resultados (cards, gráficos, tabela, revisão)
│   └── app.js                  Inicialização de cada página
├── assets/images/questoes/     Imagens originais dos enunciados e alternativas
├── docs/
│   ├── referencia-stitch/      Capturas originais do Stitch, para conferência visual
│   └── RELATORIO-IMPLEMENTACAO.md
└── .vscode/                    Recomenda a extensão Live Server
```

## Como instalar

Não há dependências para instalar nem etapa de build. Basta extrair o ZIP.

É necessária **conexão com a internet** ao abrir as páginas, porque o layout do Stitch usa o
Tailwind CSS via CDN (`cdn.tailwindcss.com`) e as fontes Inter / Material Symbols do Google Fonts.

## Como executar localmente

Escolha uma opção:

1. **Abrir direto:** dê dois cliques em `index.html` (funciona em Chrome, Edge e Firefox).
2. **VS Code + Live Server (recomendado):** abra a pasta `neurometric` no VS Code, instale a extensão
   sugerida *Live Server* e clique em **Go Live**.
3. **Servidor estático pelo terminal**, dentro da pasta `neurometric`:
   ```bash
   python -m http.server 8000      # depois acesse http://localhost:8000
   # ou
   npx serve .
   ```

> Os dados ficam no navegador e são separados por origem: quem abre por `file://` e depois por
> `http://localhost` terá contas e tentativas diferentes em cada endereço.

## Como navegar

- **Página inicial:** “Iniciar teste” leva à preparação; “Entrar” / “Acessar com Login” levam ao login.
- **Preparação:** “Iniciar Quiz” exige login. Sem login, vai para a tela de login e, após entrar ou
  cadastrar, abre direto a Questão 1. Se houver um teste em andamento, o botão vira “Retomar teste”.
- **Login / Cadastro:** as abas alternam entre as duas telas. Conta já existente não precisa de novo cadastro.
- **Questões:** escolha uma alternativa (pode trocar antes de confirmar) e clique em
  “Próxima questão”. O botão fica desabilitado até haver seleção. Na Questão 12 o botão é “Finalizar teste”.
- **Pausar teste:** link no rodapé de cada questão/memorização. Congela os dois cronômetros até clicar em “Continuar teste”.
- **Resultado:** abre automaticamente após a Questão 12. “Novo teste” volta à preparação; “Sair” encerra a sessão.

Regras do fluxo (garantidas por `js/navigation.js`): não é possível pular para uma questão futura,
voltar a uma questão confirmada, responder duas vezes, reabrir uma memorização já confirmada ou
abrir o resultado antes do fim. Ao atualizar a página, a tentativa é restaurada na etapa correta,
com a seleção ainda não confirmada e os cronômetros consistentes.

## Onde ficam as respostas

Tudo é gravado no **localStorage** do navegador (DevTools → Application → Local Storage), com prefixo `nm.`:

| Chave | Conteúdo |
|---|---|
| `nm.usuarios` | Contas do modo demonstrativo. A senha é guardada só como hash PBKDF2‑SHA‑256 com sal (`senha.hash`), nunca em texto puro. |
| `nm.sessao` | Sessão ativa quando “Lembrar de mim” está marcado (sem a opção, a sessão fica no **sessionStorage** e termina ao fechar o navegador). |
| `nm.tentativas.<e-mail>` | `{ atual, historico[] }` — a tentativa em andamento/última e as anteriores. |

Cada tentativa guarda `etapa`, `iniciadaEm`, `finalizadaEm`, pausas, horários de abertura de cada
questão, a seleção não confirmada (`rascunho`) e o array `respostas`:

```javascript
{
  questao: 1,
  idItem: "NM-01",
  enunciadoRef: "pages/questao-01.html",
  alternativaSelecionada: "E",
  alternativaCorreta: "E",      // preenchida na correção (tela de resultado)
  acertou: true,                // null quando o gabarito está pendente
  tempoSegundos: 18,
  tempoMs: 18342,
  iniciadaEm: "2026-10-16T14:00:00.000Z",
  respondidaEm: "2026-10-16T14:00:18.342Z",
  imagens: { enunciado: "assets/images/questoes/q01-enunciado.png", alternativas: null }
}
```

No console da tela de resultado, `NM.tentativas.atual()` mostra a tentativa e `NM_RESUMO` o resumo calculado.

## Como configurar o gabarito

Edite `js/answer-key.js`:

```javascript
NM.GABARITO = {
  1: "E", 2: "B", 3: "C", 4: "A", 5: "D",
  6: "A", 7: "B", 8: "C", 9: "D", 10: "E",
  11: null, // ← troque por "A".."E" quando definido
  12: null  // ← idem
};
```

Enquanto uma questão estiver com `null`, ela aparece como **gabarito pendente**: não conta como
acerto nem como erro, e o resultado mostra também o aproveitamento só sobre as questões corrigidas.
Tentativas já finalizadas são recorrigidas ao abrir a tela de resultado.
Explicações para a revisão podem ser adicionadas em `NM.EXPLICACOES` no mesmo arquivo.

O gabarito só é carregado em `pages/resultado.html`, então não aparece durante o teste —
mas, por estar no navegador, pode ser lido por quem inspecionar o código. Em produção, corrija no servidor.

## Como alterar o tempo de referência

Em `js/config.js`:

```javascript
NM.CONFIG = {
  totalQuestoes: 12,
  tempoReferenciaSegundos: 300,
  tempoReferenciaMinutos: 5,
  ...
};
```

Altere os dois campos juntos (ex.: 420 e 7). Landing, preparação, resultado e a linha de referência
do gráfico de barras leem esse valor. O teste nunca é encerrado ao atingir a referência.

## Integração com Java/Spring Boot

O código já separa os pontos de troca:

1. **Autenticação** (`js/auth.js`): existe um provider `api` pronto. Ative em `js/config.js`:
   ```javascript
   api: { enabled: true, baseUrl: "http://localhost:8080/api" }
   ```
   Contrato esperado:
   - `POST /api/auth/register` `{ nome, email, telefone, idade, senha }` → `201 { token, usuario: { nome, email } }` (409 se o e-mail já existe)
   - `POST /api/auth/login` `{ email, senha }` → `200 { token, usuario }` (401 se inválido)
2. **Envio da tentativa** (`NM.sync` em `js/app.js`): com a API ativa, a tentativa finalizada é enviada em
   `POST /api/tentativas` com `Authorization: Bearer <token>`.
3. **Correção no servidor (recomendado):** mova o gabarito para o banco, corrija em
   `POST /api/tentativas/{id}/finalizar` e devolva o resumo; a tela de resultado pode então buscar
   `GET /api/tentativas/{id}/resultado` em vez de usar `js/answer-key.js` e `js/scoring.js`.

Esboço do lado Spring Boot:

```java
@RestController
@RequestMapping("/api/auth")
class AuthController {
  @PostMapping("/register")
  ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest req) {
    // validar, checar e-mail duplicado (409), salvar com passwordEncoder.encode(req.senha()) — BCrypt
  }
  @PostMapping("/login")
  AuthResponse login(@Valid @RequestBody LoginRequest req) { /* autenticar e emitir JWT */ }
}

@RestController
@RequestMapping("/api/tentativas")
class TentativaController {
  @PostMapping
  TentativaResumo salvar(@AuthenticationPrincipal Usuario u, @RequestBody TentativaDTO dto) {
    // persistir respostas e tempos; corrigir com o gabarito do banco; retornar o resumo
  }
}
```

Lembre de liberar CORS para a origem do front-end e de validar no servidor os mesmos campos do cadastro.
O provider `api` não foi testado contra um servidor real, pois nenhum backend foi fornecido.

## Alterações feitas nas telas do Stitch

Só o necessário para integrar e corrigir inconsistências:

- Contagens de 34/60 questões → 12; “50 min” → 5 min; percentuais e “Questões restantes” calculados a partir de `CONFIG`.
- Imagens remotas do Stitch (`lh3.googleusercontent.com`) trocadas pelas **imagens originais** dos ZIPs, com a mesma associação letra↔imagem.
- Questão 12: o Stitch tinha **redesenhado** a grade do enunciado em SVG; foi substituída pela imagem original `q12_1.png`.
- Questão 8: o ícone de seleção dos cards de alternativa tinha sido trocado pelo texto da categoria (quebrava o layout); restaurado o ícone da Questão 7. A página também passou a carregar a fonte de ícones que já usava.
- Questão 11: o botão de zoom não abria nada; agora abre a mesma janela de ampliação das Questões 7/8/12.
- Memorização após a Q6: o fundo mostrava uma alternativa “C” pré-selecionada fictícia; agora mostra a resposta real do participante.
- Botões das memorizações ganharam a seta (“Entendido, continuar →”).
- Card “QI estimado” do resultado → “Tempo em relação à referência” (métrica descritiva, sem QI). Cards de pontuação ponderada → “Corrigidas” / “Pendentes”.
- Logotipo: os espaços reservados “img” da landing e da preparação receberam o “N” em gradiente usado nas demais telas.
- Senha pré-preenchida (`secretpass`) removida do login.
- Scripts de demonstração do Stitch (cronômetros fixos, `alert`) removidos e substituídos pelos módulos em `js/`.

Veja `docs/RELATORIO-IMPLEMENTACAO.md` para o que foi testado e as pendências.
